
'use client'
import { useState } from 'react'
import ModalVideo from 'react-modal-video'

export default function Video() {
    const [isOpen, setOpen] = useState(false)
    return (
        <>
            
    {/*Video One Start*/}
        <section className="video-one">
            <div className="container">
                <div className="video-one__inner">
                    <div className="video-one__bg"
                         style={{ backgroundImage: 'url(assets/images/backgrounds/video-one-bg.jpg)' }} ></div>
                    <div className="video-one__video-link">
                        <a onClick={() => setOpen(true)} className="video-popup">
                            <div className="video-one__video-icon">
                                <span className="fa fa-play"></span>
                                <i className="ripple"></i>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>
        {/*Video One End*/}
        <ModalVideo channel='youtube' autoplay isOpen={isOpen} videoId="Get7rqXYrbQ" onClose={() => setOpen(false)} />
        </>
    )
}
