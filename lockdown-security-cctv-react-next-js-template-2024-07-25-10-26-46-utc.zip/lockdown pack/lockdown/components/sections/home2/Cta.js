'use client'
import Link from "next/link"
export default function Cta() {
    return (
        <>
        {/*CTA Two Start */}
        <section className="cta-two">
            <div className="container">
                <div className="cta-two__inner">
                    <ul className="cta-two__list list-unstyled">
                        <li>
                            <div className="icon">
                                <span className="icon-paper-plan"></span>
                            </div>
                            <p>Old city Street,Usa<br/> 1212 New york-3500</p>
                        </li>
                        <li>
                            <div className="icon">
                                <span className="icon-call"></span>
                            </div>
                            <p><Link href="tel:+888123456765">(+888) 123 456 765</Link></p>
                        </li>
                        <li>
                            <div className="icon">
                                <span className="icon-email"></span>
                            </div>
                            <p><Link href="mailto:infoname@mail.com">infoname@mail.com</Link></p>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        {/*CTA Two End */}
        </>
    )
}
