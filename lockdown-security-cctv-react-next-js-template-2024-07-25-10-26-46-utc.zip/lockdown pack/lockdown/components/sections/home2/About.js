'use client'
import Link from "next/link"
export default function About() {
    return (
        <>

        {/*About Two Start */}
        <section className="about-two">
            <div className="container">
                <div className="row">
                    <div className="col-xl-6">
                        <div className="about-two__left">
                            <div className="section-title-two text-left">
                                <div className="section-title-two__tagline-box">
                                    <div className="section-title-two__icon">
                                        <span className="icon-gun"></span>
                                    </div>
                                    <div className="section-title-two__icon-2">
                                        <span className="icon-gun-2"></span>
                                    </div>
                                    <div className="section-title-two__shape-1">
                                        <img src="assets/images/shapes/section-title-two-shape-1.png" alt=""/>
                                    </div>
                                    <div className="section-title-two__shape-2">
                                        <img src="assets/images/shapes/section-title-two-shape-2.png" alt=""/>
                                    </div>
                                    <span className="section-title-two__tagline">Our Features</span>
                                </div>
                                <h2 className="section-title-two__title">Building a secure for foundation success</h2>
                            </div>
                            <p className="about-two__text">A specialized military unit tasked with gathering information and
                                conducting surveillance in high-risk or enemy territory A vigilant military team design
                                hi responsible for monitoring</p>
                            <div className="about-two__points-box">
                                <ul className="about-two__points list-unstyled">
                                    <li>
                                        <div className="about-two__points-shape"></div>
                                        <p>Securing What Matters</p>
                                    </li>
                                    <li>
                                        <div className="about-two__points-shape"></div>
                                        <p>Masters of Security</p>
                                    </li>
                                    <li>
                                        <div className="about-two__points-shape"></div>
                                        <p>Your Partner Protection</p>
                                    </li>
                                </ul>
                                <ul className="about-two__points about-two__points-2 list-unstyled">
                                    <li>
                                        <div className="about-two__points-shape"></div>
                                        <p>Watchful Eyes Secure Lives</p>
                                    </li>
                                    <li>
                                        <div className="about-two__points-shape"></div>
                                        <p>Shield the Digital Age</p>
                                    </li>
                                    <li>
                                        <div className="about-two__points-shape"></div>
                                        <p>the Business of Protecting</p>
                                    </li>
                                </ul>
                            </div>
                            <div className="about-two__btn-box">
                                <Link href="about" className="about-two__btn thm-btn">Discover More<span
                                        className="icon-plus"></span></Link>
                            </div>
                        </div>
                    </div>
                    <div className="col-xl-6">
                        <div className="about-two__right">
                            <div className="row">
                                <div className="col-xl-6 col-lg-6 col-md-6">
                                    <div className="about-two__img-1">
                                        <img src="assets/images/resources/about-two-img-1.jpg" alt=""/>
                                        <div className="about-two__shape-1 img-bounce">
                                            <img src="assets/images/shapes/about-two-shape-1.png" alt=""/>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-xl-6 col-lg-6 col-md-6">
                                    <div className="about-two__right-right">
                                        <div className="about-two__experience-box">
                                            <div className="about-two__experience-icon">
                                                <span className="icon-award"></span>
                                            </div>
                                            <div className="about-two__experience-content-box">
                                                <div className="about-two__experience-content count-box">
                                                    <h3>25</h3>
                                                    <p className="about-two__experience-year">Years</p>
                                                </div>
                                                <span>Experience</span>
                                            </div>
                                        </div>
                                        <div className="about-two__img-2">
                                            <img src="assets/images/resources/about-two-img-2.jpg" alt=""/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        {/*About Two End */}

        </>
    )
}
