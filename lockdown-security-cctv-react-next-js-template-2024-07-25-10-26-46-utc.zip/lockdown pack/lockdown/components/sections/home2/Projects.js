'use client'
import Link from "next/link"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"


const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 4,
    spaceBetween: 15,
    // autoplay: {
    //     delay: 2500,
    //     disableOnInteraction: false,
    // },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.srn',
        prevEl: '.srp',
    },

    // Pagination
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    breakpoints: {
        320: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        767: {
            slidesPerView: 2,
            // spaceBetween: 30,
        },
        991: {
            slidesPerView: 3,
            // spaceBetween: 30,
        },
        1199: {
            slidesPerView: 4,
            // spaceBetween: 30,
        },
        1350: {
            slidesPerView: 4,
            // spaceBetween: 30,
        },
    }



}


export default function Projects() {
    
    return (
        <>
        

        {/*Project Two Start*/}
        <section className="project-two">
            <div className="section-title-two text-center">
                <div className="section-title-two__tagline-box">
                    <div className="section-title-two__icon">
                        <span className="icon-gun"></span>
                    </div>
                    <div className="section-title-two__icon-2">
                        <span className="icon-gun-2"></span>
                    </div>
                    <div className="section-title-two__shape-1">
                        <img src="assets/images/shapes/section-title-two-shape-3.png" alt=""/>
                    </div>
                    <div className="section-title-two__shape-2">
                        <img src="assets/images/shapes/section-title-two-shape-4.png" alt=""/>
                    </div>
                    <span className="section-title-two__tagline">Recent case solve</span>
                </div>
                <h2 className="section-title-two__title">Ensuring your igital protection<br/> From Threats</h2>
            </div>
            <div className="project-two__carousel-box">
                <Swiper {...swiperOptions} className="project-two__carousel owl-carousel owl-theme thm-owl__carousel">
                    {/*Project Two Single Start*/}
                    <SwiperSlide>
                    <div className="item">
                        <div className="project-two__single">
                            <div className="project-two__img-box">
                                <div className="project-two__img">
                                    <img src="assets/images/project/project-2-1.jpg" alt=""/>
                                </div>
                            </div>
                        </div>
                    </div>
                    </SwiperSlide>
                    {/*Project Two Single End*/}
                    {/*Project Two Single Start*/}
                    <SwiperSlide>
                    <div className="item">
                        <div className="project-two__single">
                            <div className="project-two__img-box">
                                <div className="project-two__img">
                                    <img src="assets/images/project/project-2-2.jpg" alt=""/>
                                </div>
                            </div>
                        </div>
                    </div>
                    </SwiperSlide>
                    {/*Project Two Single End*/}
                    {/*Project Two Single Start*/}
                    <SwiperSlide>
                    <div className="item">
                        <div className="project-two__single">
                            <div className="project-two__img-box">
                                <div className="project-two__img">
                                    <img src="assets/images/project/project-2-3.jpg" alt=""/>
                                </div>
                            </div>
                        </div>
                    </div>
                    </SwiperSlide>
                    {/*Project Two Single End*/}
                    {/*Project Two Single Start*/}
                    <SwiperSlide>
                    <div className="item">
                        <div className="project-two__single">
                            <div className="project-two__img-box">
                                <div className="project-two__img">
                                    <img src="assets/images/project/project-2-4.jpg" alt=""/>
                                </div>
                            </div>
                        </div>
                    </div>
                    </SwiperSlide>
                    {/*Project Two Single End*/}
                    <SwiperSlide>
                    <div className="item">
                        <div className="project-two__single">
                            <div className="project-two__img-box">
                                <div className="project-two__img">
                                    <img src="assets/images/project/project-2-1.jpg" alt=""/>
                                </div>
                            </div>
                        </div>
                    </div>
                    </SwiperSlide>
                    {/*Project Two Single End*/}
                    {/*Project Two Single Start*/}
                    <SwiperSlide>
                    <div className="item">
                        <div className="project-two__single">
                            <div className="project-two__img-box">
                                <div className="project-two__img">
                                    <img src="assets/images/project/project-2-2.jpg" alt=""/>
                                </div>
                            </div>
                        </div>
                    </div>
                    </SwiperSlide>
                    {/*Project Two Single End*/}
                    {/*Project Two Single Start*/}
                    <SwiperSlide>
                    <div className="item">
                        <div className="project-two__single">
                            <div className="project-two__img-box">
                                <div className="project-two__img">
                                    <img src="assets/images/project/project-2-3.jpg" alt=""/>
                                </div>
                            </div>
                        </div>
                    </div>
                    </SwiperSlide>
                    {/*Project Two Single End*/}
                    {/*Project Two Single Start*/}
                    <SwiperSlide>
                    <div className="item">
                        <div className="project-two__single">
                            <div className="project-two__img-box">
                                <div className="project-two__img">
                                    <img src="assets/images/project/project-2-4.jpg" alt=""/>
                                </div>
                            </div>
                        </div>
                    </div>
                    </SwiperSlide>
                    {/*Project Two Single End*/}
                </Swiper>
                <p className="project-two__bottom-text">Ensuring your digital protection a secure environment<Link
                        href="project">Get
                        started<span className="icon-arrow-up"></span></Link></p>
            </div>
        </section>
        {/*Project Two End*/}
        </>
    )
}
