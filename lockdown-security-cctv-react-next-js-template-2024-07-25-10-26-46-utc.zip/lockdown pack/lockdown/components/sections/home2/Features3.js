'use client'
import Link from "next/link"
export default function Features3() {
    return (
        <>
        {/*Feature Four Start*/}
        <section className="feature-four">
            <div className="feature-four__bg-shape"
                 style={{ backgroundImage: 'url(assets/images/shapes/feature-four-bg-shape.png)' }} ></div>
            <div className="container">
                <div className="row">
                    {/*Feature Four Single Start*/}
                    <div className="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="100ms">
                        <div className="feature-four__single">
                            <div className="feature-four__icon">
                                <span className="icon-excelence"></span>
                            </div>
                            <h3 className="feature-four__title"><Link href="services">Excelence</Link></h3>
                        </div>
                    </div>
                    {/*Feature Four Single End*/}
                    {/*Feature Four Single Start*/}
                    <div className="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="200ms">
                        <div className="feature-four__single">
                            <div className="feature-four__icon">
                                <span className="icon-waterproof"></span>
                            </div>
                            <h3 className="feature-four__title"><Link href="services">Safety Respons</Link></h3>
                        </div>
                    </div>
                    {/*Feature Four Single End*/}
                    {/*Feature Four Single Start*/}
                    <div className="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="300ms">
                        <div className="feature-four__single">
                            <div className="feature-four__icon">
                                <span className="icon-lipstick"></span>
                            </div>
                            <h3 className="feature-four__title"><Link href="services">Digital Pro</Link></h3>
                        </div>
                    </div>
                    {/*Feature Four Single End*/}
                    {/*Feature Four Single Start*/}
                    <div className="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="400ms">
                        <div className="feature-four__single">
                            <div className="feature-four__icon">
                                <span className="icon-man"></span>
                            </div>
                            <h3 className="feature-four__title"><Link href="services">Trust Secure</Link></h3>
                        </div>
                    </div>
                    {/*Feature Four Single End*/}
                    <div className="col-xl-3"></div>
                    {/*Feature Four Single Start*/}
                    <div className="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="500ms">
                        <div className="feature-four__single">
                            <div className="feature-four__icon">
                                <span className="icon-shield"></span>
                            </div>
                            <h3 className="feature-four__title"><Link href="services">commitment</Link></h3>
                        </div>
                    </div>
                    {/*Feature Four Single End*/}
                    {/*Feature Four Single Start*/}
                    <div className="col-xl-3 col-lg-6 col-md-6 wow fadeInLeft" data-wow-delay="600ms">
                        <div className="feature-four__single">
                            <div className="feature-four__icon">
                                <span className="icon-peace-mind"></span>
                            </div>
                            <h3 className="feature-four__title"><Link href="services">Value</Link></h3>
                        </div>
                    </div>
                    {/*Feature Four Single End*/}
                    <div className="col-xl-3"></div>
                </div>
            </div>
        </section>
        {/*Feature Four End*/}
        </>
    )
}
