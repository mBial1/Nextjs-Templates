'use client'
import Link from "next/link"
export default function Blog() {
    return (
        <>
        {/*Blog Two Start*/}
        <section className="blog-two">
            <div className="container">
                <div className="section-title-two text-center">
                    <div className="section-title-two__tagline-box">
                        <div className="section-title-two__icon">
                            <span className="icon-gun"></span>
                        </div>
                        <div className="section-title-two__icon-2">
                            <span className="icon-gun-2"></span>
                        </div>
                        <div className="section-title-two__shape-1">
                            <img src="assets/images/shapes/section-title-two-shape-3.png" alt=""/>
                        </div>
                        <div className="section-title-two__shape-2">
                            <img src="assets/images/shapes/section-title-two-shape-4.png" alt=""/>
                        </div>
                        <span className="section-title-two__tagline">Our Blogs</span>
                    </div>
                    <h2 className="section-title-two__title">Defending against all<br/> emerging threats</h2>
                </div>
                <div className="row">
                    {/*Blog Two Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInLeft" data-wow-delay="100ms">
                        <div className="blog-two__single">
                            <div className="blog-two__img-box">
                                <div className="blog-two__img">
                                    <img src="assets/images/news/blog-2-1.jpg" alt=""/>
                                    <Link href="blog-details">
                                        <span className="blog-two__plus"></span>
                                    </Link>
                                </div>
                                <div className="blog-two__date">
                                    <p>Oct 19</p>
                                </div>
                            </div>
                            <div className="blog-two__content">
                                <h3 className="blog-two__title"><Link href="blog-details">Empowering you with<br/> secure
                                        technologies</Link></h3>
                                <Link href="blog-details" className="blog-two__btn">Discover More<span
                                        className="icon-plus"></span></Link>
                            </div>
                        </div>
                    </div>
                    {/*Blog Two Single End*/}
                    {/*Blog Two Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <div className="blog-two__single">
                            <div className="blog-two__img-box">
                                <div className="blog-two__img">
                                    <img src="assets/images/news/blog-2-2.jpg" alt=""/>
                                    <Link href="blog-details">
                                        <span className="blog-two__plus"></span>
                                    </Link>
                                </div>
                                <div className="blog-two__date">
                                    <p>Oct 19</p>
                                </div>
                            </div>
                            <div className="blog-two__content">
                                <h3 className="blog-two__title"><Link href="blog-details">Protecting what you<br/> value
                                        most</Link></h3>
                                <Link href="blog-details" className="blog-two__btn">Discover More<span
                                        className="icon-plus"></span></Link>
                            </div>
                        </div>
                    </div>
                    {/*Blog Two Single End*/}
                    {/*Blog Two Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInRight" data-wow-delay="100ms">
                        <div className="blog-two__single">
                            <div className="blog-two__img-box">
                                <div className="blog-two__img">
                                    <img src="assets/images/news/blog-2-3.jpg" alt=""/>
                                    <Link href="blog-details">
                                        <span className="blog-two__plus"></span>
                                    </Link>
                                </div>
                                <div className="blog-two__date">
                                    <p>Oct 19</p>
                                </div>
                            </div>
                            <div className="blog-two__content">
                                <h3 className="blog-two__title"><Link href="blog-details">Securing your business<br/>
                                        securing
                                        your reputation</Link></h3>
                                <Link href="blog-details" className="blog-two__btn">Discover More<span
                                        className="icon-plus"></span></Link>
                            </div>
                        </div>
                    </div>
                    {/*Blog Two Single End*/}
                </div>
            </div>
        </section>
        {/*Blog Two End*/}
        </>
    )
}
