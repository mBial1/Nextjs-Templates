'use client'
export default function Features() {
    return (
        <>
        {/*Feature Two Start */}
        <section className="feature-two">
            <div className="container">
                <div className="row">
                    {/*Feature Two Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <div className="feature-two__single">
                            <div className="feature-two__img">
                                <img src="assets/images/resources/feature-2-1.jpg" alt=""/>
                            </div>
                        </div>
                    </div>
                    {/*Feature Two Single End*/}
                    {/*Feature Two Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                        <div className="feature-two__single">
                            <div className="feature-two__img">
                                <img src="assets/images/resources/feature-2-2.jpg" alt=""/>
                            </div>
                        </div>
                    </div>
                    {/*Feature Two Single End*/}
                    {/*Feature Two Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                        <div className="feature-two__single">
                            <div className="feature-two__img">
                                <img src="assets/images/resources/feature-2-3.jpg" alt=""/>
                            </div>
                        </div>
                    </div>
                    {/*Feature Two Single End*/}
                </div>
            </div>
        </section>
        {/*Feature Two End */}
        </>
    )
}
