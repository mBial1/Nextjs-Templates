'use client'
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"


const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 1,
    spaceBetween: 30,
    // autoplay: {
    //     delay: 2500,
    //     disableOnInteraction: false,
    // },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.srn',
        prevEl: '.srp',
    },

    // Pagination
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    breakpoints: {
        320: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        767: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        991: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        1199: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        1350: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
    }



}

export default function Testimonial() {
    
    return (
        <>
            {/*Testimonial Two Start */}
        <section className="testimonial-two">
            <div className="container">
                <div className="testimonial-two__inner">
                    <Swiper {...swiperOptions} className="testimonial-two__carousel owl-carousel owl-theme thm-owl__carousel">
                        {/*Testimonial Two Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="testimonial-two__single">
                                <div className="testimonial-two__img">
                                    <img src="assets/images/testimonial/testimonial-2-1.jpg" alt=""/>
                                </div>
                                <div className="testimonial-two__content">
                                    <div className="testimonial-two__shape-1">
                                        <img src="assets/images/shapes/testimonial-two-shape-1.png" alt=""/>
                                    </div>
                                    <div className="testimonial-two__client-and-ratting">
                                        <div className="testimonial-two__client-info">
                                            <h3>Mike Luverge</h3>
                                            <p>CEO founder</p>
                                        </div>
                                        <div className="testimonial-two__ratting">
                                            <i className="icon-star"></i>
                                            <i className="icon-star"></i>
                                            <i className="icon-star"></i>
                                            <i className="icon-star"></i>
                                            <i className="icon-star"></i>
                                        </div>
                                    </div>
                                    <p className="testimonial-two__text">A specialized military unit tasked with gathering
                                        information and conducting wai surveillance in high-risk or enemy territory. A
                                        vigilant military team responsibl in for monitoring A specialized military unit
                                        tasked with gathering information andi conducting surveillance in high-risk or
                                        enemy territory. A vigilant military teams responsible for monitoring A
                                        specialized military unit tasked with gathering information and conducting
                                        surveillance in hig</p>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Testimonial Two Single End*/}
                        {/*Testimonial Two Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="testimonial-two__single">
                                <div className="testimonial-two__img">
                                    <img src="assets/images/testimonial/testimonial-2-2.jpg" alt=""/>
                                </div>
                                <div className="testimonial-two__content">
                                    <div className="testimonial-two__shape-1">
                                        <img src="assets/images/shapes/testimonial-two-shape-1.png" alt=""/>
                                    </div>
                                    <div className="testimonial-two__client-and-ratting">
                                        <div className="testimonial-two__client-info">
                                            <h3>Robert Hardson</h3>
                                            <p>CEO founder</p>
                                        </div>
                                        <div className="testimonial-two__ratting">
                                            <i className="icon-star"></i>
                                            <i className="icon-star"></i>
                                            <i className="icon-star"></i>
                                            <i className="icon-star"></i>
                                            <i className="icon-star"></i>
                                        </div>
                                    </div>
                                    <p className="testimonial-two__text">A specialized military unit tasked with gathering
                                        information and conducting wai surveillance in high-risk or enemy territory. A
                                        vigilant military team responsibl in for monitoring A specialized military unit
                                        tasked with gathering information andi conducting surveillance in high-risk or
                                        enemy territory. A vigilant military teams responsible for monitoring A
                                        specialized military unit tasked with gathering information and conducting
                                        surveillance in hig</p>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Testimonial Two Single End*/}
                    </Swiper>
                </div>
            </div>
        </section>
        {/*Testimonial Two End */}


        </>
    )
}
