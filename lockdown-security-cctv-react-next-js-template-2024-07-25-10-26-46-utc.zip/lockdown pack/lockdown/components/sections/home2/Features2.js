'use client'
import Link from "next/link"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"


const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 4,
    spaceBetween: 30,
    // autoplay: {
    //     delay: 2500,
    //     disableOnInteraction: false,
    // },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.srn',
        prevEl: '.srp',
    },

    // Pagination
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },



}

export default function Features2() {
    return (
        <>
        {/*Feature Three Start */}
        <section className="feature-three">
            <div className="feature-three__bg-shape float-bob-x"
                 style={{ backgroundImage: 'url(assets/images/shapes/feature-three-bg-shape.png)' }} ></div>
            <div className="container">
                <div className="section-title-two text-center">
                    <div className="section-title-two__tagline-box">
                        <div className="section-title-two__icon">
                            <span className="icon-gun"></span>
                        </div>
                        <div className="section-title-two__icon-2">
                            <span className="icon-gun-2"></span>
                        </div>
                        <div className="section-title-two__shape-1">
                            <img src="assets/images/shapes/section-title-two-shape-1.png" alt=""/>
                        </div>
                        <div className="section-title-two__shape-2">
                            <img src="assets/images/shapes/section-title-two-shape-2.png" alt=""/>
                        </div>
                        <span className="section-title-two__tagline">Our Features</span>
                    </div>
                    <h2 className="section-title-two__title">Securing business securing<br/> your reputation</h2>
                </div>
                <div className="feature-three__bottom">
                    <Swiper {...swiperOptions} className="feature-three__carousel owl-carousel owl-theme thm-owl__carousel">
                        {/*Feature Three Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="feature-three__single">
                                <div className="feature-three__icon">
                                    <span className="icon-home"></span>
                                </div>
                                <h3 className="feature-three__title"><Link href="services-details">Streamlining
                                        <br/>security</Link></h3>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Feature Three Single End*/}
                        {/*Feature Three Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="feature-three__single">
                                <div className="feature-three__icon">
                                    <span className="icon-file"></span>
                                </div>
                                <h3 className="feature-three__title"><Link href="services-details">Digital<br/> agents</Link>
                                </h3>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Feature Three Single End*/}
                        {/*Feature Three Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="feature-three__single">
                                <div className="feature-three__icon">
                                    <span className="icon-finger"></span>
                                </div>
                                <h3 className="feature-three__title"><Link href="services-details">Emerging<br/>
                                        threats</Link></h3>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Feature Three Single End*/}
                        {/*Feature Three Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="feature-three__single">
                                <div className="feature-three__icon">
                                    <span className="icon-sunlight"></span>
                                </div>
                                <h3 className="feature-three__title"><Link href="services-details">securing
                                        <br/>reputation</Link></h3>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Feature Three Single End*/}
                        {/*Feature Three Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="feature-three__single">
                                <div className="feature-three__icon">
                                    <span className="icon-home"></span>
                                </div>
                                <h3 className="feature-three__title"><Link href="services-details">Streamlining
                                        <br/>security</Link></h3>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Feature Three Single End*/}
                        {/*Feature Three Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="feature-three__single">
                                <div className="feature-three__icon">
                                    <span className="icon-file"></span>
                                </div>
                                <h3 className="feature-three__title"><Link href="services-details">Digital<br/> agents</Link>
                                </h3>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Feature Three Single End*/}
                        {/*Feature Three Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="feature-three__single">
                                <div className="feature-three__icon">
                                    <span className="icon-finger"></span>
                                </div>
                                <h3 className="feature-three__title"><Link href="services-details">Emerging<br/>
                                        threats</Link></h3>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Feature Three Single End*/}
                        {/*Feature Three Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="feature-three__single">
                                <div className="feature-three__icon">
                                    <span className="icon-sunlight"></span>
                                </div>
                                <h3 className="feature-three__title"><Link href="services-details">securing
                                        <br/>reputation</Link></h3>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Feature Three Single End*/}
                        {/*Feature Three Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="feature-three__single">
                                <div className="feature-three__icon">
                                    <span className="icon-home"></span>
                                </div>
                                <h3 className="feature-three__title"><Link href="services-details">Streamlining
                                        <br/>security</Link></h3>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Feature Three Single End*/}
                        {/*Feature Three Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="feature-three__single">
                                <div className="feature-three__icon">
                                    <span className="icon-file"></span>
                                </div>
                                <h3 className="feature-three__title"><Link href="services-details">Digital<br/> agents</Link>
                                </h3>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Feature Three Single End*/}
                        {/*Feature Three Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="feature-three__single">
                                <div className="feature-three__icon">
                                    <span className="icon-finger"></span>
                                </div>
                                <h3 className="feature-three__title"><Link href="services-details">Emerging<br/>
                                        threats</Link></h3>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Feature Three Single End*/}
                        {/*Feature Three Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="feature-three__single">
                                <div className="feature-three__icon">
                                    <span className="icon-sunlight"></span>
                                </div>
                                <h3 className="feature-three__title"><Link href="services-details">securing
                                        <br/>reputation</Link></h3>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Feature Three Single End*/}
                        {/*Feature Three Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="feature-three__single">
                                <div className="feature-three__icon">
                                    <span className="icon-home"></span>
                                </div>
                                <h3 className="feature-three__title"><Link href="services-details">Streamlining
                                        <br/>security</Link></h3>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Feature Three Single End*/}
                        {/*Feature Three Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="feature-three__single">
                                <div className="feature-three__icon">
                                    <span className="icon-file"></span>
                                </div>
                                <h3 className="feature-three__title"><Link href="services-details">Digital<br/> agents</Link>
                                </h3>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Feature Three Single End*/}
                        {/*Feature Three Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="feature-three__single">
                                <div className="feature-three__icon">
                                    <span className="icon-finger"></span>
                                </div>
                                <h3 className="feature-three__title"><Link href="services-details">Emerging<br/>
                                        threats</Link></h3>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Feature Three Single End*/}
                        {/*Feature Three Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="feature-three__single">
                                <div className="feature-three__icon">
                                    <span className="icon-sunlight"></span>
                                </div>
                                <h3 className="feature-three__title"><Link href="services-details">securing
                                        <br/>reputation</Link></h3>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Feature Three Single End*/}
                    </Swiper>
                </div>
            </div>
        </section>
        {/*Feature Three End */}
        </>
    )
}
