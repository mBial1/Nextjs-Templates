
'use client'
import Link from "next/link"
export default function Banner() {
    return (
        <>

        {/* Banner One Start */}
        <section className="banner-one">
            <div className="banner-one__shape-1 float-bob-x">
                <img src="assets/images/shapes/banner-one-shape-1.png" alt=""/>
            </div>
            <div className="banner-one__side-text">Taking security to the next level</div>
            <div className="container">
                <div className="row">
                    <div className="col-xl-7">
                        <div className="banner-one__left">
                            <h2 className="banner-one__title wow fadeInLeft" data-wow-delay="100ms">Defending against <br/>
                                digital threats</h2>
                            <p className="banner-one__text wow fadeInRight" data-wow-delay="100ms">A specialized military
                                unit tasked with gathering information
                                and <br/> conducting surveillance in high-risk or enemy</p>
                            <div className="banner-one__btn-box wow fadeInUp" data-wow-delay="100ms">
                                <Link href="about" className="banner-one__btn thm-btn">Discover More<span
                                        className="icon-plus"></span></Link>
                            </div>
                        </div>
                    </div>
                    <div className="col-xl-5">
                        <div className="banner-one__right">
                            <h2 className="banner-one__right-title">secure <br/> tomorrow</h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        {/* Banner One End */}

        </>
    )
}
