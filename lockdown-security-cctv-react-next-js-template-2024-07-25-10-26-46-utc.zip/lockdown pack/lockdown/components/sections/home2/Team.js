'use client'
import Link from "next/link"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"


const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 1,
    spaceBetween: 30,
    // autoplay: {
    //     delay: 2500,
    //     disableOnInteraction: false,
    // },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.srn',
        prevEl: '.srp',
    },

    // Pagination
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    breakpoints: {
        320: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        767: {
            slidesPerView: 2,
            // spaceBetween: 30,
        },
        991: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        1199: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        1350: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
    }



}
export default function Team() {
    return (
        <>
            {/*Team One Start*/}
        <section className="team-one">
            <div className="container">
                <div className="team-one__top">
                    <div className="section-title-two text-left">
                        <div className="section-title-two__tagline-box">
                            <div className="section-title-two__icon">
                                <span className="icon-gun"></span>
                            </div>
                            <div className="section-title-two__icon-2">
                                <span className="icon-gun-2"></span>
                            </div>
                            <div className="section-title-two__shape-1">
                                <img src="assets/images/shapes/section-title-two-shape-1.png" alt=""/>
                            </div>
                            <div className="section-title-two__shape-2">
                                <img src="assets/images/shapes/section-title-two-shape-2.png" alt=""/>
                            </div>
                            <span className="section-title-two__tagline">the team</span>
                        </div>
                        <h2 className="section-title-two__title">Your Shield in a World<br/> of Uncertainty</h2>
                    </div>
                    <p className="team-one__top-text">Their product exceeded his my daily design routine expectations wa<br/>
                        The
                        quality and heres attention to detail were outstanding and it isi<br/> has become an essential
                    </p>
                </div>
                <div className="team-one__bottom">
                    <Swiper {...swiperOptions} className="team-one__carousel owl-carousel owl-theme thm-owl__carousel">
                        {/*Team One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="team-one__single">
                                <div className="team-one__img">
                                    <img src="assets/images/team/team-1-1.jpg" alt=""/>
                                </div>
                                <div className="team-one__content">
                                    <div className="team-one__shape-1">
                                        <img src="assets/images/shapes/team-one-shape-1.png" alt=""/>
                                    </div>
                                    <h3 className="team-one__title">Michael Ramirez</h3>
                                    <p className="team-one__text">Their product exceeded his my daily design routine
                                        expectations wa The quality and heres quality and heres attention to detail were
                                        outstanding and it isi has become an essential</p>
                                    <div className="team-one__social">
                                        <Link href="#"><span className="icon-facebook"></span></Link>
                                        <Link href="#"><span className="icon-twitter"></span></Link>
                                        <Link href="#"><span className="icon-linkin"></span></Link>
                                        <Link href="#"><span className="icon-pinterest"></span></Link>
                                    </div>
                                    <div className="team-one__client-info">
                                        <h3>Annette Black</h3>
                                        <p>Security guard</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Team One Single End*/}
                        {/*Team One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="team-one__single">
                                <div className="team-one__img">
                                    <img src="assets/images/team/team-1-2.jpg" alt=""/>
                                </div>
                                <div className="team-one__content">
                                    <div className="team-one__shape-1">
                                        <img src="assets/images/shapes/team-one-shape-1.png" alt=""/>
                                    </div>
                                    <h3 className="team-one__title">Adam Smith</h3>
                                    <p className="team-one__text">Their product exceeded his my daily design routine
                                        expectations wa The quality and heres quality and heres attention to detail were
                                        outstanding and it isi has become an essential</p>
                                    <div className="team-one__social">
                                        <Link href="#"><span className="icon-facebook"></span></Link>
                                        <Link href="#"><span className="icon-twitter"></span></Link>
                                        <Link href="#"><span className="icon-linkin"></span></Link>
                                        <Link href="#"><span className="icon-pinterest"></span></Link>
                                    </div>
                                    <div className="team-one__client-info">
                                        <h3>Annette Black</h3>
                                        <p>Security guard</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Team One Single End*/}
                         {/*Team One Single Start*/}
                         <SwiperSlide>
                        <div className="item">
                            <div className="team-one__single">
                                <div className="team-one__img">
                                    <img src="assets/images/team/team-1-1.jpg" alt=""/>
                                </div>
                                <div className="team-one__content">
                                    <div className="team-one__shape-1">
                                        <img src="assets/images/shapes/team-one-shape-1.png" alt=""/>
                                    </div>
                                    <h3 className="team-one__title">Michael Ramirez</h3>
                                    <p className="team-one__text">Their product exceeded his my daily design routine
                                        expectations wa The quality and heres quality and heres attention to detail were
                                        outstanding and it isi has become an essential</p>
                                    <div className="team-one__social">
                                        <Link href="#"><span className="icon-facebook"></span></Link>
                                        <Link href="#"><span className="icon-twitter"></span></Link>
                                        <Link href="#"><span className="icon-linkin"></span></Link>
                                        <Link href="#"><span className="icon-pinterest"></span></Link>
                                    </div>
                                    <div className="team-one__client-info">
                                        <h3>Annette Black</h3>
                                        <p>Security guard</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Team One Single End*/}
                        {/*Team One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="team-one__single">
                                <div className="team-one__img">
                                    <img src="assets/images/team/team-1-2.jpg" alt=""/>
                                </div>
                                <div className="team-one__content">
                                    <div className="team-one__shape-1">
                                        <img src="assets/images/shapes/team-one-shape-1.png" alt=""/>
                                    </div>
                                    <h3 className="team-one__title">Adam Smith</h3>
                                    <p className="team-one__text">Their product exceeded his my daily design routine
                                        expectations wa The quality and heres quality and heres attention to detail were
                                        outstanding and it isi has become an essential</p>
                                    <div className="team-one__social">
                                        <Link href="#"><span className="icon-facebook"></span></Link>
                                        <Link href="#"><span className="icon-twitter"></span></Link>
                                        <Link href="#"><span className="icon-linkin"></span></Link>
                                        <Link href="#"><span className="icon-pinterest"></span></Link>
                                    </div>
                                    <div className="team-one__client-info">
                                        <h3>Annette Black</h3>
                                        <p>Security guard</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Team One Single End*/}
                    </Swiper>
                </div>
            </div>
        </section>
        {/*Team One End*/}
        </>
    )
}
