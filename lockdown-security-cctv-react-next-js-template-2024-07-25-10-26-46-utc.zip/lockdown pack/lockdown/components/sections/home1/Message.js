'use client'
import Link from "next/link"
export default function Message() {
    return (
        <>

     {/*Message One Start */}
     <section className="message-one">
            <div className="message-one__bg"  style={{ backgroundImage: 'url(assets/images/backgrounds/message-one-bg.jpg)' }} >
            </div>
            <div className="container">
                <div className="section-title text-center">
                    <div className="section-title__tagline-box">
                        <span className="section-title__tagline">message us</span>
                    </div>
                    <h2 className="section-title__title">Keeping you one step ahead<br/> of threats</h2>
                </div>
                <div className="message-one__inner">
                    <div className="row">
                        {/*Message One Single Start*/}
                        <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                            <div className="message-one__single">
                                <div className="message-one__icon">
                                    <span className="icon-cup"></span>
                                </div>
                                <h3 className="message-one__title"><Link href="about">Level Up</Link></h3>
                            </div>
                        </div>
                        {/*Message One Single End*/}
                        {/*Message One Single Start*/}
                        <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                            <div className="message-one__single">
                                <div className="message-one__icon">
                                    <span className="icon-online-secure"></span>
                                </div>
                                <h3 className="message-one__title"><Link href="about">Online Secure</Link></h3>
                            </div>
                        </div>
                        {/*Message One Single End*/}
                        {/*Message One Single Start*/}
                        <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="600ms">
                            <div className="message-one__single">
                                <div className="message-one__icon">
                                    <span className="icon-safety"></span>
                                </div>
                                <h3 className="message-one__title"><Link href="about">Safety Respons</Link></h3>
                            </div>
                        </div>
                        {/*Message One Single End*/}
                        {/*Message One Single Start*/}
                        <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="900ms">
                            <div className="message-one__single">
                                <div className="message-one__icon">
                                    <span className="icon-threat"></span>
                                </div>
                                <h3 className="message-one__title"><Link href="about">Threat Ahead</Link></h3>
                            </div>
                        </div>
                        {/*Message One Single End*/}
                        {/*Message One Single Start*/}
                        <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="1200ms">
                            <div className="message-one__single">
                                <div className="message-one__icon">
                                    <span className="icon-man"></span>
                                </div>
                                <h3 className="message-one__title"><Link href="about">Trust Secure</Link></h3>
                            </div>
                        </div>
                        {/*Message One Single End*/}
                        {/*Message One Single Start*/}
                        <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="1500ms">
                            <div className="message-one__single">
                                <div className="message-one__icon">
                                    <span className="icon-bottol"></span>
                                </div>
                                <h3 className="message-one__title"><Link href="about">Digital Pro</Link></h3>
                            </div>
                        </div>
                        {/*Message One Single End*/}
                    </div>
                    <div className="message-one__bottom">
                        <form className="message-one__form mc-form" data-url="MC_FORM_URL">
                            <div className="message-one__form-input-box">
                                <input type="text" placeholder="Enter you ptoduct..." name="text"/>
                                <button type="submit" className="message-one__btn thm-btn">Discover More<span
                                        className="icon-plus"></span></button>
                            </div>
                        </form>
                        <div className="mc-form__response"></div>
                        <p className="message-one__bottom-text">Ensuring your digital protection a secure environment<Link
                                href="contact">Get started<span className="icon-arrow-up"></span></Link></p>
                    </div>
                </div>
            </div>
        </section>
        {/*Message One End */}
            

        </>
    )
}
