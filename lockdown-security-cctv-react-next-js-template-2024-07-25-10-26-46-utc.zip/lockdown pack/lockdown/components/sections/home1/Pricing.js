'use client'
import Link from "next/link"
export default function Pricing() {
    
    return (
        <>
        {/*Pricing One Start */}
        <section className="pricing-one">
            <div className="container">
                <div className="pricing-one__top">
                    <div className="row">
                        <div className="col-xl-7">
                            <div className="section-title text-left">
                                <div className="section-title__tagline-box">
                                    <span className="section-title__tagline">Best Pricing</span>
                                </div>
                                <h2 className="section-title__title">aking security to the<br/> next level</h2>
                            </div>
                        </div>
                        <div className="col-xl-5">
                            <p className="pricing-one__top-text">A specialized military unit tasked with gathering
                                information<br/> and conducting surveillance in high-risk </p>
                        </div>
                    </div>
                </div>
                <div className="row">
                    {/*Pricing Ine Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <div className="pricing-one__single">
                            <div className="pricing-one__icon">
                                <span className="icon-seaech-1"></span>
                            </div>
                            <h3 className="pricing-one__title">Starter plan</h3>
                            <h3 className="pricing-one__price">$19<span>/mo</span></h3>
                            <ul className="pricing-one__points list-unstyled">
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>IP Camera</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Night Vision Mode</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Data Guard</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Full Motion Capture</p>
                                </li>
                            </ul>
                            <div className="pricing-one__btn-box">
                                <Link href="contact" className="pricing-one__btn thm-btn">Discover More<span
                                        className="icon-plus"></span></Link>
                            </div>
                        </div>
                    </div>
                    {/*Pricing Ine Single End*/}
                    {/*Pricing Ine Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                        <div className="pricing-one__single">
                            <div className="pricing-one__icon">
                                <span className="icon-computer"></span>
                            </div>
                            <h3 className="pricing-one__title">Premium plan</h3>
                            <h3 className="pricing-one__price">$29<span>/mo</span></h3>
                            <ul className="pricing-one__points list-unstyled">
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>IP Camera</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Night Vision Mode</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Data Guard</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Full Motion Capture</p>
                                </li>
                            </ul>
                            <div className="pricing-one__btn-box">
                                <Link href="contact" className="pricing-one__btn thm-btn">Discover More<span
                                        className="icon-plus"></span></Link>
                            </div>
                        </div>
                    </div>
                    {/*Pricing Ine Single End*/}
                    {/*Pricing Ine Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="600ms">
                        <div className="pricing-one__single">
                            <div className="pricing-one__icon">
                                <span className="icon-love"></span>
                            </div>
                            <h3 className="pricing-one__title">Gold plan</h3>
                            <h3 className="pricing-one__price">$39<span>/mo</span></h3>
                            <ul className="pricing-one__points list-unstyled">
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>IP Camera</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Night Vision Mode</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Data Guard</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Full Motion Capture</p>
                                </li>
                            </ul>
                            <div className="pricing-one__btn-box">
                                <Link href="contact" className="pricing-one__btn thm-btn">Discover More<span
                                        className="icon-plus"></span></Link>
                            </div>
                        </div>
                    </div>
                    {/*Pricing Ine Single End*/}
                </div>
            </div>
        </section>
        {/*Pricing One End */}
        </>
    )
}
