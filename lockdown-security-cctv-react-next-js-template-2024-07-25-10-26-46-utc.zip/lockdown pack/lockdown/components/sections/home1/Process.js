
'use client'
import Link from "next/link"
export default function Process() {
    return (
        <>
        {/*Process One Start */}
        <section className="process-one">
            <div className="container">
                <div className="row">
                    <div className="col-xl-6">
                        <div className="process-one__left">
                            <div className="section-title text-left">
                                <div className="section-title__tagline-box">
                                    <span className="section-title__tagline">Work Process</span>
                                </div>
                                <h2 className="section-title__title">Securing your peace of mind is our top priority</h2>
                            </div>
                            <p className="process-one__text-1">A specialized military unit tasked with gathering information
                                and conducting surveillance in high-risk </p>
                            <ul className="process-one__process-list list-unstyled">
                                <li className="wow fadeInLeft" data-wow-delay="100ms">
                                    <div className="process-one__count"></div>
                                    <div className="icon">
                                        <span className="icon-peace-mind"></span>
                                    </div>
                                    <h3><Link href="about">Peace Mind</Link></h3>
                                </li>
                                <li className="wow fadeInLeft" data-wow-delay="300ms">
                                    <div className="process-one__count"></div>
                                    <div className="icon">
                                        <span className="icon-shoes"></span>
                                    </div>
                                    <h3><Link href="about">Threat Defense</Link></h3>
                                </li>
                                <li className="wow fadeInLeft" data-wow-delay="600ms">
                                    <div className="process-one__count"></div>
                                    <div className="icon">
                                        <span className="icon-emil-2"></span>
                                    </div>
                                    <h3><Link href="about">Digital Fortress</Link></h3>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div className="col-xl-6">
                        <div className="process-one__right wow slideInRight" data-wow-delay="100ms"
                            data-wow-duration="2500ms">
                            <div className="row">
                                <div className="col-xl-6 col-lg-6 col-md-6">
                                    <div className="process-one__img-box">
                                        <div className="process-one__img">
                                            <img src="assets/images/resources/process-one-img-1.jpg" alt=""/>
                                        </div>
                                        <div className="process-one__count-box">
                                            <p className="process-one__count-text">Trusted By</p>
                                            <div className="process-one__count-2 count-box">
                                                <h3>10</h3>
                                                <span className="process-one__count-plus">k</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-xl-6 col-lg-6 col-md-6">
                                    <div className="process-one__img-box-2">
                                        <div className="process-one__img-2">
                                            <img src="assets/images/resources/process-one-img-2.jpg" alt=""/>
                                        </div>
                                        <div className="process-one__img-3">
                                            <img src="assets/images/resources/process-one-img-3.jpg" alt=""/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        {/*Process One End */}
        </>
    )
}
