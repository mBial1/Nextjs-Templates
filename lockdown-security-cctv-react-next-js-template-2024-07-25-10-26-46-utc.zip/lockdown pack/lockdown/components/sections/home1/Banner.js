
'use client'
import Link from "next/link"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"

const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 1,
    spaceBetween: 0,
    // autoplay: {
    //     delay: 2500,
    //     disableOnInteraction: false,
    // },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.h1n',
        prevEl: '.h1p',
    },

    // Pagination
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },



}

export default function Banner() {
    return (
        <>
            {/* Main Sllider Start */}
        <section className="main-slider">
            <Swiper {...swiperOptions} className="main-slider__carousel owl-carousel owl-theme thm-owl__carousel"
                data-owl-options='{"loop": true, "items": 1, "navText": ["<span className=\"icon-left-arrow\"></span>","<span className=\"icon-right-arrow\"></span>"], "margin": 0, "dots": true, "nav": false, "animateOut": "slideOutDown", "animateIn": "fadeIn", "active": true, "smartSpeed": 1000, "autoplay": true, "autoplayTimeout": 7000, "autoplayHoverPause": false}'>
                <SwiperSlide>
                <div className="item main-slider__slide-1">
                    <div className="main-slider__bg"
                         style={{ backgroundImage: 'url(assets/images/backgrounds/slider-1-1.jpg)' }} >
                    </div>{/* /.slider-one__bg */}
                    <div className="main-slider__bg-two"
                         style={{ backgroundImage: 'url(assets/images/backgrounds/slider-img-1-1.png)' }} >
                    </div>{/* /.slider-one__bg */}
                    <div className="main-slider__shape-1">
                        <img src="assets/images/shapes/main-slider-shape-1.png" alt=""/>
                    </div>
                    <div className="main-slider__shape-2">
                        <img src="assets/images/shapes/main-slider-shape-2.png" alt=""/>
                    </div>
                    <div className="main-slider__shape-3">
                        <img src="assets/images/shapes/main-slider-shape-3.png" alt=""/>
                    </div>
                    <div className="main-slider__shape-4">
                        <img src="assets/images/shapes/main-slider-shape-4.png" alt=""/>
                    </div>
                    <div className="container">
                        <div className="main-slider__content">
                            <p className="main-slider__sub-title">lockdown</p>
                            <h2 className="main-slider__title">Building <span className="icon-camera"></span> trust <br/> with
                                security!
                            </h2>
                            <p className="main-slider__text">Their product exceeded his my daily design routine expectations
                                wa <br/> The quality and heres attention to detail were outstanding</p>
                            <div className="main-slider__btn-and-call-box">
                                <div className="main-slider__btn-box">
                                    <Link href="about" className="main-slider__btn thm-btn">Learn More</Link>
                                </div>
                                <div className="main-slider__call">
                                    <div className="main-slider__call-icon">
                                        <span className="icon-call-2"></span>
                                    </div>
                                    <div className="main-slider__call-content">
                                        <p className="main-slider__call-sub-title">Need help?</p>
                                        <h5 className="main-slider__call-number"><Link href="tel:3195550115">(319) 555-0115</Link>
                                        </h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </SwiperSlide>
                <SwiperSlide>
                <div className="item main-slider__slide-1">
                    <div className="main-slider__bg"
                         style={{ backgroundImage: 'url(assets/images/backgrounds/slider-1-2.jpg)' }} >
                    </div>{/* /.slider-one__bg */}
                    <div className="main-slider__bg-two"
                         style={{ backgroundImage: 'url(assets/images/backgrounds/slider-img-1-1.png)' }} >
                    </div>{/* /.slider-one__bg */}
                    <div className="main-slider__shape-1">
                        <img src="assets/images/shapes/main-slider-shape-1.png" alt=""/>
                    </div>
                    <div className="main-slider__shape-2">
                        <img src="assets/images/shapes/main-slider-shape-2.png" alt=""/>
                    </div>
                    <div className="main-slider__shape-3">
                        <img src="assets/images/shapes/main-slider-shape-3.png" alt=""/>
                    </div>
                    <div className="main-slider__shape-4">
                        <img src="assets/images/shapes/main-slider-shape-4.png" alt=""/>
                    </div>
                    <div className="container">
                        <div className="main-slider__content">
                            <p className="main-slider__sub-title">lockdown</p>
                            <h2 className="main-slider__title">Building <span className="icon-camera"></span> trust <br/> with
                                security!
                            </h2>
                            <p className="main-slider__text">Their product exceeded his my daily design routine expectations
                                wa <br/> The quality and heres attention to detail were outstanding</p>
                            <div className="main-slider__btn-and-call-box">
                                <div className="main-slider__btn-box">
                                    <Link href="about" className="main-slider__btn thm-btn">Learn More</Link>
                                </div>
                                <div className="main-slider__call">
                                    <div className="main-slider__call-icon">
                                        <span className="icon-call-2"></span>
                                    </div>
                                    <div className="main-slider__call-content">
                                        <p className="main-slider__call-sub-title">Need help?</p>
                                        <h5 className="main-slider__call-number"><Link href="tel:3195550115">(319) 555-0115</Link>
                                        </h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </SwiperSlide>
                <SwiperSlide>
                <div className="item main-slider__slide-1">
                    <div className="main-slider__bg"
                         style={{ backgroundImage: 'url(assets/images/backgrounds/slider-1-3.jpg)' }} >
                    </div>{/* /.slider-one__bg */}
                    <div className="main-slider__bg-two"
                         style={{ backgroundImage: 'url(assets/images/backgrounds/slider-img-1-1.png)' }} >
                    </div>{/* /.slider-one__bg */}
                    <div className="main-slider__shape-1">
                        <img src="assets/images/shapes/main-slider-shape-1.png" alt=""/>
                    </div>
                    <div className="main-slider__shape-2">
                        <img src="assets/images/shapes/main-slider-shape-2.png" alt=""/>
                    </div>
                    <div className="main-slider__shape-3">
                        <img src="assets/images/shapes/main-slider-shape-3.png" alt=""/>
                    </div>
                    <div className="main-slider__shape-4">
                        <img src="assets/images/shapes/main-slider-shape-4.png" alt=""/>
                    </div>
                    <div className="container">
                        <div className="main-slider__content">
                            <p className="main-slider__sub-title">lockdown</p>
                            <h2 className="main-slider__title">Building <span className="icon-camera"></span> trust <br/> with
                                security!
                            </h2>
                            <p className="main-slider__text">Their product exceeded his my daily design routine expectations
                                wa <br/> The quality and heres attention to detail were outstanding</p>
                            <div className="main-slider__btn-and-call-box">
                                <div className="main-slider__btn-box">
                                    <Link href="about" className="main-slider__btn thm-btn">Learn More</Link>
                                </div>
                                <div className="main-slider__call">
                                    <div className="main-slider__call-icon">
                                        <span className="icon-call-2"></span>
                                    </div>
                                    <div className="main-slider__call-content">
                                        <p className="main-slider__call-sub-title">Need help?</p>
                                        <h5 className="main-slider__call-number"><Link href="tel:3195550115">(319) 555-0115</Link>
                                        </h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </SwiperSlide>
            </Swiper>
        </section>
        {/*Main Sllider Start */}
            
        </>
    )
}
