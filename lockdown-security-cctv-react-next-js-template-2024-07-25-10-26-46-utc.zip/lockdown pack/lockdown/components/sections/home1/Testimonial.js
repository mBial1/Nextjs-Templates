'use client'
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"


const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 2,
    spaceBetween: 30,
    // autoplay: {
    //     delay: 2500,
    //     disableOnInteraction: false,
    // },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.srn',
        prevEl: '.srp',
    },

    // Pagination
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    breakpoints: {
        320: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        767: {
            slidesPerView: 2,
            // spaceBetween: 30,
        },
        991: {
            slidesPerView: 2,
            // spaceBetween: 30,
        },
        1199: {
            slidesPerView: 2,
            // spaceBetween: 30,
        },
        1350: {
            slidesPerView: 2,
            // spaceBetween: 30,
        },
    }



}


export default function Testimonial() {
    return (
        <>

        {/*Testimonial One Start */}
        <section className="testimonial-one">
            <div className="testimonial-one__shape-2 float-bob-y">
                <img src="assets/images/shapes/testimonial-one-shape-2.png" alt=""/>
            </div>
            <div className="container">
                <div className="section-title text-left">
                    <div className="section-title__tagline-box">
                        <span className="section-title__tagline">CLIENTS REVIEWS</span>
                    </div>
                    <h2 className="section-title__title">WHAT OUR CLIENT SAYS</h2>
                </div>
                <p className="testimonial-one__text">A specialized military unit tasked with gathering information and<br/>
                    conducting surveillance in high-risk </p>
                <div className="testimonial-one__bottom">
                    <Swiper {...swiperOptions} className="testimonial-one__carousel owl-carousel owl-theme thm-owl__carousel">
                        {/*Testimonial One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="testimonial-one__single">
                                <div className="testimonial-one__shape-1">
                                    <img src="assets/images/shapes/testimonial-one-shape-1.png" alt=""/>
                                </div>
                                <div className="testimonial-one__ratting-and-quote">
                                    <div className="testimonial-one__ratting">
                                        <i className="icon-star"></i>
                                        <i className="icon-star"></i>
                                        <i className="icon-star"></i>
                                        <i className="icon-star"></i>
                                        <i className="icon-star icon-star-2"></i>
                                    </div>
                                    <div className="testimonial-one__quote">
                                        <span className="icon-quote"></span>
                                    </div>
                                </div>
                                <p className="testimonial-one__single-text">Their product exceeded his my daily design
                                    routine expectations wa The quality and heres attention to detail were outstanding
                                    and it isi has become an essential</p>
                                <div className="testimonial-one__client-box">
                                    <div className="testimonial-one__client-img">
                                        <img src="assets/images/testimonial/testimonial-1-1.png" alt=""/>
                                    </div>
                                    <div className="testimonial-one__client-info">
                                        <h3>Michael Ramirez</h3>
                                        <p>CEO Of Google</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Testimonial One Single End*/}
                        {/*Testimonial One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="testimonial-one__single">
                                <div className="testimonial-one__shape-1">
                                    <img src="assets/images/shapes/testimonial-one-shape-1.png" alt=""/>
                                </div>
                                <div className="testimonial-one__ratting-and-quote">
                                    <div className="testimonial-one__ratting">
                                        <i className="icon-star"></i>
                                        <i className="icon-star"></i>
                                        <i className="icon-star"></i>
                                        <i className="icon-star"></i>
                                        <i className="icon-star icon-star-2"></i>
                                    </div>
                                    <div className="testimonial-one__quote">
                                        <span className="icon-quote"></span>
                                    </div>
                                </div>
                                <p className="testimonial-one__single-text">Their product exceeded his my daily design
                                    routine expectations wa The quality and heres attention to detail were outstanding
                                    and it isi has become an essential</p>
                                <div className="testimonial-one__client-box">
                                    <div className="testimonial-one__client-img">
                                        <img src="assets/images/testimonial/testimonial-1-2.png" alt=""/>
                                    </div>
                                    <div className="testimonial-one__client-info">
                                        <h3>Alisha Martin</h3>
                                        <p>CEO Of Google</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Testimonial One Single End*/}
                        {/*Testimonial One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="testimonial-one__single">
                                <div className="testimonial-one__shape-1">
                                    <img src="assets/images/shapes/testimonial-one-shape-1.png" alt=""/>
                                </div>
                                <div className="testimonial-one__ratting-and-quote">
                                    <div className="testimonial-one__ratting">
                                        <i className="icon-star"></i>
                                        <i className="icon-star"></i>
                                        <i className="icon-star"></i>
                                        <i className="icon-star"></i>
                                        <i className="icon-star icon-star-2"></i>
                                    </div>
                                    <div className="testimonial-one__quote">
                                        <span className="icon-quote"></span>
                                    </div>
                                </div>
                                <p className="testimonial-one__single-text">Their product exceeded his my daily design
                                    routine expectations wa The quality and heres attention to detail were outstanding
                                    and it isi has become an essential</p>
                                <div className="testimonial-one__client-box">
                                    <div className="testimonial-one__client-img">
                                        <img src="assets/images/testimonial/testimonial-1-1.png" alt=""/>
                                    </div>
                                    <div className="testimonial-one__client-info">
                                        <h3>Michael Ramirez</h3>
                                        <p>CEO Of Google</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Testimonial One Single End*/}
                        {/*Testimonial One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="testimonial-one__single">
                                <div className="testimonial-one__shape-1">
                                    <img src="assets/images/shapes/testimonial-one-shape-1.png" alt=""/>
                                </div>
                                <div className="testimonial-one__ratting-and-quote">
                                    <div className="testimonial-one__ratting">
                                        <i className="icon-star"></i>
                                        <i className="icon-star"></i>
                                        <i className="icon-star"></i>
                                        <i className="icon-star"></i>
                                        <i className="icon-star icon-star-2"></i>
                                    </div>
                                    <div className="testimonial-one__quote">
                                        <span className="icon-quote"></span>
                                    </div>
                                </div>
                                <p className="testimonial-one__single-text">Their product exceeded his my daily design
                                    routine expectations wa The quality and heres attention to detail were outstanding
                                    and it isi has become an essential</p>
                                <div className="testimonial-one__client-box">
                                    <div className="testimonial-one__client-img">
                                        <img src="assets/images/testimonial/testimonial-1-2.png" alt=""/>
                                    </div>
                                    <div className="testimonial-one__client-info">
                                        <h3>Alisha Martin</h3>
                                        <p>CEO Of Google</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Testimonial One Single End*/}
                    </Swiper>
                </div>
            </div>
        </section>
        {/*Testimonial One End */}
            
        </>
    )
}
