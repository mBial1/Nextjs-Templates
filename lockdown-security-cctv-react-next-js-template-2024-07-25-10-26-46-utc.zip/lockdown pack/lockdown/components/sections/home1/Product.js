'use client'
export default function Product() {
    
    return (
        <>
        {/*Product One Start */}
        <section className="product-one">
            <div className="container">
                <div className="row">
                    <div className="col-xl-6">
                        <div className="product-one__left">
                            <div className="section-title text-left">
                                <div className="section-title__tagline-box">
                                    <span className="section-title__tagline">Product</span>
                                </div>
                                <h2 className="section-title__title">Keeping you one step<br/> ahead of threats</h2>
                            </div>
                            <p className="product-one__text">A specialized military unit tasked with gathering information
                                and conducting surveillance in high-risk </p>
                            <div className="product-one__img">
                                <img src="assets/images/resources/product-one-img-1.jpg" alt=""/>
                            </div>
                        </div>
                    </div>
                    <div className="col-xl-6">
                        <div className="product-one__right wow slideInRight" data-wow-delay="100ms"
                            data-wow-duration="2500ms">
                            <form action="assets/inc/sendemail.php" className="product-one__form contact-form-validated"
                                >
                                <div className="product-one__single-list">
                                    <div className="select-box">
                                        <select className="wide">
                                            <option data-display="Camera Type*">Camera Type*</option>
                                            <option value="1">Sort by popular</option>
                                            <option value="2">Sort by Price</option>
                                            <option value="3">Sort by Ratings</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="product-one__single-list">
                                    <div className="select-box">
                                        <select className="wide">
                                            <option data-display="Storage Amount*">Storage Amount*</option>
                                            <option value="1">Sort by popular</option>
                                            <option value="2">Sort by Price</option>
                                            <option value="3">Sort by Ratings</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="product-one__single-list">
                                    <div className="select-box">
                                        <select className="wide">
                                            <option data-display="Piece">Piece</option>
                                            <option value="1">Sort by popular</option>
                                            <option value="2">Sort by Price</option>
                                            <option value="3">Sort by Ratings</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="product-one__single-list">
                                    <div className="select-box">
                                        <select className="wide">
                                            <option data-display="Pixel quality*">Pixel quality*</option>
                                            <option value="1">Sort by popular</option>
                                            <option value="2">Sort by Price</option>
                                            <option value="3">Sort by Ratings</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="product-one__btn-box">
                                    <button type="submit" className="thm-btn product-one__btn">BUY NOW<span
                                            className="icon-plus"></span></button>
                                </div>
                            </form>
                            <div className="result"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        {/*Product One End */}
        </>
    )
}
