'use client'
import Link from "next/link"
import { useState } from 'react'

export default function About() {
    const [isOpen, setOpen] = useState(false)
    return (
        <>

          {/*About One Start */}
        <section className="about-one">
            <div className="container">
                <div className="row">
                    <div className="col-xl-6">
                        <div className="about-one__left">
                            <div className="about-one__img-box wow slideInLeft" data-wow-delay="100ms"
                                data-wow-duration="2500ms">
                                <div className="about-one__img">
                                    <img src="assets/images/resources/about-one-img-1.jpg" alt=""/>
                                </div>
                                <div className="about-one__happy-client">
                                    <div className="about-one__happy-client-inner">
                                        <div className="about-one__happy-client-count count-box">
                                            <h3>3000</h3>
                                            <span className="about-one__happy-client-plus">+</span>
                                        </div>
                                        <p className="about-one__happy-client-text">Happy</p>
                                    </div>
                                    <p className="about-one__happy-client-text-2">Clients</p>
                                </div>
                                <div className="about-one__experience">
                                    <div className="about-one__experience-count count-box">
                                        <h3>15</h3>
                                        <span className="about-one__experience-plus">+</span>
                                    </div>
                                    <p className="about-one__experience-text">YEARS OF EXPERIENCE</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-xl-6">
                        <div className="about-one__right">
                            <div className="section-title text-left">
                                <div className="section-title__tagline-box">
                                    <span className="section-title__tagline">about us</span>
                                </div>
                                <h2 className="section-title__title">Protecting you is our top priority system</h2>
                            </div>
                            <p className="about-one__text">A specialized military unit tasked with gathering information and
                                de conducting surveillance in high-risk or enemy territory. A vigilant wa military team
                                responsible for monitoring</p>
                            <div className="about-one__points-box">
                                <ul className="about-one__points-list list-unstyled">
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Top Guard</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Cyber Shield</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Peace Mind</p>
                                    </li>
                                </ul>
                                <ul className="about-one__points-list about-one__points-list-2 list-unstyled">
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Threat Defense</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Digital Fortres</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Cyber Power</p>
                                    </li>
                                </ul>
                            </div>
                            <p className="about-one__text-2">A specialized military unit tasked with gathering information
                                and conducting surveillance in high-risk </p>
                            <div className="about-one__btn-box">
                                <Link href="about" className="about-one__btn thm-btn">Discover More<span
                                        className="icon-plus"></span></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        {/*About One End */}
        </>
    )
}
