'use client'
import Link from "next/link"
import { useState } from "react"


export default function Features() {
    const [activeIndex, setActiveIndex] = useState(1)
    const handleOnClick = (index) => {
        setActiveIndex(index)
    }
    return (
        <>
        {/*Feature One Start */}
        <section className="feature-one">
            <div className="container">
                <div className="section-title text-left">
                    <div className="section-title__tagline-box">
                        <span className="section-title__tagline">features</span>
                    </div>
                    <h2 className="section-title__title">Guarding your digital fortress is<br/> our responsibility</h2>
                </div>
                <div className="feature-one__inner tabs-box">
                    <div className="feature-one__tab-box clearfix">
                        <ul className="tab-buttons clearfix list-unstyled">
                        <li className={activeIndex == 1 ? "tab-btn active-btn" : "tab-btn"} onClick={() => handleOnClick(1)}>
                                <div className="feature-one__tab-btn">
                                    <span>Racidential</span>
                                </div>
                            </li>
                            <li className={activeIndex == 2 ? "tab-btn active-btn" : "tab-btn"} onClick={() => handleOnClick(2)}>
                                <div className="feature-one__tab-btn feature-one__tab-btn-2">
                                    <span>Commercial</span>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div className="feature-one__bottom">
                        <div className="tabs-content">
                            {/*tab*/}
                            <div className={activeIndex == 1 ? "tab fadeInUp animated show active-tab" : "tab fadeInUp animated"}>
                                <ul className="feature-one__feature-list list-unstyled">
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-ip-camera"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">IP
                                                    <br/>Camera</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-vision"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Night
                                                    Vision<br/> Mode</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-data-guard"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Data Sync<br/>
                                                    Guard</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-motion"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Full
                                                    Motion<br/> Capture</Link></h3>
                                        </div>
                                    </li>
                                </ul>
                                <ul className="feature-one__feature-list list-unstyled">
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-sunglass"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Smart
                                                    <br/>Detector</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-okitok"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Trust
                                                    <br/>Secure</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-waterproof"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link
                                                    href="services-details">Waterproof<br/> System</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-backup-power"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Backup
                                                    <br/>power</Link></h3>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            {/*tab*/}
                            {/*tab*/}
                            <div className={activeIndex == 2 ? "tab fadeInUp animated show active-tab" : "tab fadeInUp animated"}>
                                <ul className="feature-one__feature-list list-unstyled">
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-ip-camera"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">IP
                                                    <br/>Camera</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-vision"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Night
                                                    Vision<br/> Mode</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-data-guard"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Data Sync<br/>
                                                    Guard</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-motion"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Full
                                                    Motion<br/> Capture</Link></h3>
                                        </div>
                                    </li>
                                </ul>
                                <ul className="feature-one__feature-list list-unstyled">
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-sunglass"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Smart
                                                    <br/>Detector</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-okitok"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Trust
                                                    <br/>Secure</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-waterproof"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link
                                                    href="services-details">Waterproof<br/> System</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-backup-power"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Backup
                                                    <br/>power</Link></h3>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            {/*tab*/}
                        </div>
                    </div>
                </div>
            </div>
        </section>
        {/*Feature One End */}
        </>
    )
}
