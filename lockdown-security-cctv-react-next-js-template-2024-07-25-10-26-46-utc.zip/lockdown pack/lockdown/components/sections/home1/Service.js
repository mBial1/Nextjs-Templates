'use client'
import Link from "next/link"
export default function Service() {
    return (
        <>

     {/*Services One Start */}
     <section className="services-one">
            <div className="container">
                <div className="section-title text-center">
                    <div className="section-title__tagline-box">
                        <span className="section-title__tagline">our service</span>
                    </div>
                    <h2 className="section-title__title">Keeping you one step<br/> ahead of threats</h2>
                </div>
                <div className="row">
                    {/*Services One Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInLeft" data-wow-delay="100ms">
                        <div className="services-one__single">
                            <div className="services-one__img-box">
                                <div className="services-one__img">
                                    <img src="assets/images/services/services-1-1.jpg" alt=""/>
                                </div>
                                <div className="services-one__icon">
                                    <span className="icon-watch"></span>
                                </div>
                            </div>
                            <div className="services-one__content">
                                <h3 className="services-one__title"><Link href="services-details">Cyber Fighter</Link></h3>
                                <p className="services-one__text">A specialized military unit tasked with gathering
                                    information </p>
                                <div className="services-one__btn-box">
                                    <Link href="services-details" className="services-one__btn thm-btn">Discover More<span
                                            className="icon-plus"></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/*Services One Single End*/}
                    {/*Services One Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="200ms">
                        <div className="services-one__single">
                            <div className="services-one__img-box">
                                <div className="services-one__img">
                                    <img src="assets/images/services/services-1-2.jpg" alt=""/>
                                </div>
                                <div className="services-one__icon">
                                    <span className="icon-doller"></span>
                                </div>
                            </div>
                            <div className="services-one__content">
                                <h3 className="services-one__title"><Link href="services-details">Online Secure</Link></h3>
                                <p className="services-one__text">A specialized military unit tasked with gathering
                                    information </p>
                                <div className="services-one__btn-box">
                                    <Link href="services-details" className="services-one__btn thm-btn">Discover More<span
                                            className="icon-plus"></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/*Services One Single End*/}
                    {/*Services One Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInRight" data-wow-delay="300ms">
                        <div className="services-one__single">
                            <div className="services-one__img-box">
                                <div className="services-one__img">
                                    <img src="assets/images/services/services-1-3.jpg" alt=""/>
                                </div>
                                <div className="services-one__icon">
                                    <span className="icon-enviroment"></span>
                                </div>
                            </div>
                            <div className="services-one__content">
                                <h3 className="services-one__title"><Link href="services-details">Safe Enviro</Link></h3>
                                <p className="services-one__text">A specialized military unit tasked with gathering
                                    information </p>
                                <div className="services-one__btn-box">
                                    <Link href="services-details" className="services-one__btn thm-btn">Discover More<span
                                            className="icon-plus"></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/*Services One Single End*/}
                </div>
            </div>
        </section>
        {/*Services One End */}
        </>
    )
}
