'use client'
import Link from "next/link"
export default function Blog() {
    return (
        <>
        {/*Blog One Start */}
        <section className="blog-one">
            <div className="container">
                <div className="section-title text-center">
                    <div className="section-title__tagline-box">
                        <span className="section-title__tagline">Our Blogs</span>
                    </div>
                    <h2 className="section-title__title">Empowering you with<br/> cybersecurity</h2>
                </div>
                <div className="row">
                    {/*Blog One Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInLeft" data-wow-delay="100ms">
                        <div className="blog-one__single">
                            <div className="blog-one__img-box">
                                <div className="blog-one__img">
                                    <img src="assets/images/news/blog-1-1.jpg" alt=""/>
                                </div>
                            </div>
                            <div className="blog-one__content">
                                <ul className="blog-one__meta list-unstyled">
                                    <li>
                                        <Link href="blog-details"><span className="icon-user"></span>By admin</Link>
                                    </li>
                                    <li>
                                        <Link href="blog-details"><span className="icon-calender"></span>October 19,
                                            2022</Link>
                                    </li>
                                </ul>
                                <h3 className="blog-one__title"><Link href="blog-details">A security solution that brings
                                        peace of mind</Link></h3>
                                <div className="blog-one__btn-box">
                                    <Link href="blog-details" className="blog-one__btn thm-btn">Discover More<span
                                            className="icon-plus"></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/*Blog One Single End*/}
                    {/*Blog One Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <div className="blog-one__single">
                            <div className="blog-one__img-box">
                                <div className="blog-one__img">
                                    <img src="assets/images/news/blog-1-2.jpg" alt=""/>
                                </div>
                            </div>
                            <div className="blog-one__content">
                                <ul className="blog-one__meta list-unstyled">
                                    <li>
                                        <Link href="blog-details"><span className="icon-user"></span>By admin</Link>
                                    </li>
                                    <li>
                                        <Link href="blog-details"><span className="icon-calender"></span>October 19,
                                            2022</Link>
                                    </li>
                                </ul>
                                <h3 className="blog-one__title"><Link href="blog-details"> Provides robust defense
                                        mechanisms to</Link></h3>
                                <div className="blog-one__btn-box">
                                    <Link href="blog-details" className="blog-one__btn thm-btn">Discover More<span
                                            className="icon-plus"></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/*Blog One Single End*/}
                    {/*Blog One Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInRight" data-wow-delay="100ms">
                        <div className="blog-one__single">
                            <div className="blog-one__img-box">
                                <div className="blog-one__img">
                                    <img src="assets/images/news/blog-1-3.jpg" alt=""/>
                                </div>
                            </div>
                            <div className="blog-one__content">
                                <ul className="blog-one__meta list-unstyled">
                                    <li>
                                        <Link href="blog-details"><span className="icon-user"></span>By admin</Link>
                                    </li>
                                    <li>
                                        <Link href="blog-details"><span className="icon-calender"></span>October 19,
                                            2022</Link>
                                    </li>
                                </ul>
                                <h3 className="blog-one__title"><Link href="blog-details">Builds a strong fortress around
                                        your </Link></h3>
                                <div className="blog-one__btn-box">
                                    <Link href="blog-details" className="blog-one__btn thm-btn">Discover More<span
                                            className="icon-plus"></span></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/*Blog One Single End*/}
                </div>
            </div>
        </section>
        {/*Blog One End */}
        </>
    )
}
