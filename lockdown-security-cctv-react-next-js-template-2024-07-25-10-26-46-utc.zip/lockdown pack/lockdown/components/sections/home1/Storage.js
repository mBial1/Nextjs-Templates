'use client'
import Link from "next/link"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import { Swiper, SwiperSlide } from "swiper/react"


const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 3,
    spaceBetween: 30,
    // autoplay: {
    //     delay: 2500,
    //     disableOnInteraction: false,
    // },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.srn',
        prevEl: '.srp',
    },

    // Pagination
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    breakpoints: {
        320: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        767: {
            slidesPerView: 2,
            // spaceBetween: 30,
        },
        991: {
            slidesPerView: 2,
            // spaceBetween: 30,
        },
        1199: {
            slidesPerView: 2,
            // spaceBetween: 30,
        },
        1350: {
            slidesPerView: 3,
            // spaceBetween: 30,
        },
    }



}
export default function Storage() {
    return (
        <>
        {/*Storage One Start */}
        <section className="storage-one">
            <div className="container">
                <div className="section-title text-left">
                    <div className="section-title__tagline-box">
                        <span className="section-title__tagline">our Storage</span>
                    </div>
                    <h2 className="section-title__title">Ensuring your igital Threats<br/> protection From </h2>
                </div>
                <div className="storage-one__bottom">
                    <Swiper {...swiperOptions} className="storage-one__carousel owl-carousel owl-theme thm-owl__carousel">
                        {/*Storage One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="storage-one__single">
                                <div className="storage-one__img-box">
                                    <div className="storage-one__img">
                                        <img src="assets/images/storage/storage-1-1.jpg" alt=""/>
                                    </div>
                                    <div className="storage-one__content">
                                        <div className="storage-one__icon">
                                            <span className="icon-cloud"></span>
                                        </div>
                                        <h3 className="storage-one__title"><Link href="project-details">Cloud storage</Link>
                                        </h3>
                                        <p className="storage-one__text">A specialized military unit tasked with gathering
                                            information</p>
                                        <div className="storage-one__arrow">
                                            <Link href="project-details" className="icon-long-arrow-right"></Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Storage One Single End*/}
                        {/*Storage One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="storage-one__single">
                                <div className="storage-one__img-box">
                                    <div className="storage-one__img">
                                        <img src="assets/images/storage/storage-1-2.jpg" alt=""/>
                                    </div>
                                    <div className="storage-one__content">
                                        <div className="storage-one__icon">
                                            <span className="icon-cloud"></span>
                                        </div>
                                        <h3 className="storage-one__title"><Link href="project-details">Cloud storage</Link>
                                        </h3>
                                        <p className="storage-one__text">A specialized military unit tasked with gathering
                                            information</p>
                                        <div className="storage-one__arrow">
                                            <Link href="project-details" className="icon-long-arrow-right"></Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Storage One Single End*/}
                        {/*Storage One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="storage-one__single">
                                <div className="storage-one__img-box">
                                    <div className="storage-one__img">
                                        <img src="assets/images/storage/storage-1-3.jpg" alt=""/>
                                    </div>
                                    <div className="storage-one__content">
                                        <div className="storage-one__icon">
                                            <span className="icon-cloud"></span>
                                        </div>
                                        <h3 className="storage-one__title"><Link href="project-details">Cloud storage</Link>
                                        </h3>
                                        <p className="storage-one__text">A specialized military unit tasked with gathering
                                            information</p>
                                        <div className="storage-one__arrow">
                                            <Link href="project-details" className="icon-long-arrow-right"></Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Storage One Single End*/}
                        {/*Storage One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="storage-one__single">
                                <div className="storage-one__img-box">
                                    <div className="storage-one__img">
                                        <img src="assets/images/storage/storage-1-4.jpg" alt=""/>
                                    </div>
                                    <div className="storage-one__content">
                                        <div className="storage-one__icon">
                                            <span className="icon-cloud"></span>
                                        </div>
                                        <h3 className="storage-one__title"><Link href="project-details">Cloud storage</Link>
                                        </h3>
                                        <p className="storage-one__text">A specialized military unit tasked with gathering
                                            information</p>
                                        <div className="storage-one__arrow">
                                            <Link href="project-details" className="icon-long-arrow-right"></Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Storage One Single End*/}
                        {/*Storage One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="storage-one__single">
                                <div className="storage-one__img-box">
                                    <div className="storage-one__img">
                                        <img src="assets/images/storage/storage-1-5.jpg" alt=""/>
                                    </div>
                                    <div className="storage-one__content">
                                        <div className="storage-one__icon">
                                            <span className="icon-cloud"></span>
                                        </div>
                                        <h3 className="storage-one__title"><Link href="project-details">Cloud storage</Link>
                                        </h3>
                                        <p className="storage-one__text">A specialized military unit tasked with gathering
                                            information</p>
                                        <div className="storage-one__arrow">
                                            <Link href="project-details" className="icon-long-arrow-right"></Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Storage One Single End*/}
                    </Swiper>
                </div>
                <p className="storage-one__bottom-text">Ensuring your digital protection a secure environment<Link
                        href="project">Get
                        started<span className="icon-arrow-up"></span></Link></p>
            </div>
        </section>
        {/*Storage One End */}
        </>
    )
}
