import Link from "next/link"
// import { useRouter } from "next/router"

export default function Menu() {
    // const router = useRouter()


    return (
        <>

            {/* <ul className="sub-menu">
                <Link className={router.pathname == "/" ? "active" : ""}>Home Default</Link>
                <Link className={router.pathname == "/index-2" ? "active" : ""}>Home Interior</Link>
            </ul> */}

       
            <ul className="main-menu__list">
                <li className="dropdown">
                    <Link href="/">Home </Link>
                    <ul>
                        <li><Link href="/">Home One</Link></li>
                        <li><Link href="index-2">Home Two</Link></li>
                    </ul>
                </li>
                <li>
                    <Link href="about">About</Link>
                </li>
                <li className="dropdown">
                    <Link href="#">Pages</Link>
                    <ul>
                        <li><Link href="team">Team</Link></li>
                        <li><Link href="team-details">Team Details</Link></li>
                        <li><Link href="team-carousel">Team Carousel</Link></li>
                        <li><Link href="gallery">Gallery</Link></li>
                        <li><Link href="faq">Faq</Link></li>
                        <li><Link href="/error">404 Error</Link></li>
                    </ul>
                </li>
                <li className="dropdown">
                    <Link href="#">Services</Link>
                    <ul>
                        <li><Link href="services">Services</Link></li>
                        <li><Link href="services-carousel">Services Carousel</Link></li>
                        <li><Link href="services-details">Service Details</Link></li>
                        
                    </ul>
                </li>
                <li className="dropdown">
                    <Link href="#">Project</Link>
                    <ul>
                        <li><Link href="project">Project</Link></li>
                        <li><Link href="project-carousel">Project Carousel</Link></li>
                        <li><Link href="project-details">Project Details</Link></li>
                        
                    </ul>
                </li>
                <li className="dropdown">
                    <Link href="#">Blog</Link>
                    <ul>
                        <li><Link href="blog">Blog</Link></li>
                        <li><Link href="blog-carousel">Blog Carousel</Link></li>
                        <li><Link href="blog-details">Blog Details</Link></li>
                    </ul>
                </li>
                <li>
                    <Link href="contact">Contact</Link>
                </li>
            </ul>
        </>
    )
}
