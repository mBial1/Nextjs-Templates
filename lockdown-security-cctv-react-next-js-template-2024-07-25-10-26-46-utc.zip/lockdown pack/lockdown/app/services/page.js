
import Layout from "@/components/layout/Layout"
import Link from "next/link"
export default function Home() {

    return (
        <>
            <Layout headerStyle={3} footerStyle={1} breadcrumbTitle="Our services">
                <div>
                    {/*Services Page Start */}
                    <section className="services-page">
                        <div className="container">
                            <div className="row">
                                {/*Services One Single Start*/}
                                <div className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="services-one__single">
                                        <div className="services-one__img-box">
                                            <div className="services-one__img">
                                                <img src="assets/images/services/services-page-1-1.jpg" alt=""/>
                                            </div>
                                            <div className="services-one__icon">
                                                <span className="icon-watch"></span>
                                            </div>
                                        </div>
                                        <div className="services-one__content">
                                            <h3 className="services-one__title"><Link href="services-details">Cyber Fighter</Link></h3>
                                            <p className="services-one__text">A specialized military unit tasked with gathering
                                                information </p>
                                            <div className="services-one__btn-box">
                                                <Link href="services-details" className="services-one__btn thm-btn">Discover More<span
                                                        className="icon-plus"></span></Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/*Services One Single End*/}
                                {/*Services One Single Start*/}
                                <div className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="services-one__single">
                                        <div className="services-one__img-box">
                                            <div className="services-one__img">
                                                <img src="assets/images/services/services-page-1-2.jpg" alt=""/>
                                            </div>
                                            <div className="services-one__icon">
                                                <span className="icon-doller"></span>
                                            </div>
                                        </div>
                                        <div className="services-one__content">
                                            <h3 className="services-one__title"><Link href="services-details">Online Secure</Link></h3>
                                            <p className="services-one__text">A specialized military unit tasked with gathering
                                                information </p>
                                            <div className="services-one__btn-box">
                                                <Link href="services-details" className="services-one__btn thm-btn">Discover More<span
                                                        className="icon-plus"></span></Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/*Services One Single End*/}
                                {/*Services One Single Start*/}
                                <div className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="services-one__single">
                                        <div className="services-one__img-box">
                                            <div className="services-one__img">
                                                <img src="assets/images/services/services-page-1-3.jpg" alt=""/>
                                            </div>
                                            <div className="services-one__icon">
                                                <span className="icon-enviroment"></span>
                                            </div>
                                        </div>
                                        <div className="services-one__content">
                                            <h3 className="services-one__title"><Link href="services-details">Safe Enviro</Link></h3>
                                            <p className="services-one__text">A specialized military unit tasked with gathering
                                                information </p>
                                            <div className="services-one__btn-box">
                                                <Link href="services-details" className="services-one__btn thm-btn">Discover More<span
                                                        className="icon-plus"></span></Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/*Services One Single End*/}
                                {/*Services One Single Start*/}
                                <div className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="services-one__single">
                                        <div className="services-one__img-box">
                                            <div className="services-one__img">
                                                <img src="assets/images/services/services-page-1-4.jpg" alt=""/>
                                            </div>
                                            <div className="services-one__icon">
                                                <span className="icon-okitok"></span>
                                            </div>
                                        </div>
                                        <div className="services-one__content">
                                            <h3 className="services-one__title"><Link href="services-details">Fighter Cyber </Link></h3>
                                            <p className="services-one__text">A specialized military unit tasked with gathering
                                                information </p>
                                            <div className="services-one__btn-box">
                                                <Link href="services-details" className="services-one__btn thm-btn">Discover More<span
                                                        className="icon-plus"></span></Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/*Services One Single End*/}
                                {/*Services One Single Start*/}
                                <div className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="services-one__single">
                                        <div className="services-one__img-box">
                                            <div className="services-one__img">
                                                <img src="assets/images/services/services-page-1-5.jpg" alt=""/>
                                            </div>
                                            <div className="services-one__icon">
                                                <span className="icon-waterproof"></span>
                                            </div>
                                        </div>
                                        <div className="services-one__content">
                                            <h3 className="services-one__title"><Link href="services-details">Offline Secure</Link></h3>
                                            <p className="services-one__text">A specialized military unit tasked with gathering
                                                information </p>
                                            <div className="services-one__btn-box">
                                                <Link href="services-details" className="services-one__btn thm-btn">Discover More<span
                                                        className="icon-plus"></span></Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/*Services One Single End*/}
                                {/*Services One Single Start*/}
                                <div className="col-xl-4 col-lg-4 col-md-6">
                                    <div className="services-one__single">
                                        <div className="services-one__img-box">
                                            <div className="services-one__img">
                                                <img src="assets/images/services/services-page-1-6.jpg" alt=""/>
                                            </div>
                                            <div className="services-one__icon">
                                                <span className="icon-peace-mind"></span>
                                            </div>
                                        </div>
                                        <div className="services-one__content">
                                            <h3 className="services-one__title"><Link href="services-details">Safe cctv </Link></h3>
                                            <p className="services-one__text">A specialized military unit tasked with gathering
                                                information </p>
                                            <div className="services-one__btn-box">
                                                <Link href="services-details" className="services-one__btn thm-btn">Discover More<span
                                                        className="icon-plus"></span></Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                {/*Services One Single End*/}
                            </div>
                        </div>
                    </section>
                    {/*Services Page End */}
                    {/*CTA One Start */}
                    <section className="cta-one">
                        <div className="container">
                            <div className="cta-one__inner">
                                <div className="cta-one__bg"  style={{ backgroundImage: 'url(assets/images/backgrounds/cta-one-bg.jpg)' }} >
                                </div>
                                <div className="row">
                                    <div className="col-xl-6 col-lg-6"></div>
                                    <div className="col-xl-6 col-lg-6">
                                        <div className="cta-one__right">
                                            <h3 className="cta-one__title">Get Free Estimate</h3>
                                            <p className="cta-one__text">Lorem Ipsum is simply is dumiomy is text Lorem Ipsum </p>
                                            <form className="cta-one__form mc-form" data-url="MC_FORM_URL">
                                                <div className="cta-one__form-input-box">
                                                    <input type="email" placeholder="Your email..." name="email"/>
                                                    <button type="submit" className="cta-one__btn thm-btn">Login<span
                                                            className="icon-plus"></span></button>
                                                </div>
                                            </form>
                                            <div className="mc-form__response"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    {/*CTA One End */}
                </div>

            </Layout>
        </>
    )
}