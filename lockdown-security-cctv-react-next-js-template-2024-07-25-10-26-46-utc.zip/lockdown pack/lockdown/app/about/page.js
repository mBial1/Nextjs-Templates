'use client'
import Layout from "@/components/layout/Layout"
import { Autoplay, Navigation, Pagination } from "swiper/modules"
import Link from "next/link"
import { useState } from 'react'
import { Swiper, SwiperSlide } from "swiper/react"
import BrandSlider from "@/components/slider/BrandSlider"


const swiperOptions = {
    modules: [Autoplay, Pagination, Navigation],
    slidesPerView: 3,
    spaceBetween: 30,
    // autoplay: {
    //     delay: 2500,
    //     disableOnInteraction: false,
    // },
    loop: true,

    // Navigation
    navigation: {
        nextEl: '.srn',
        prevEl: '.srp',
    },

    // Pagination
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    breakpoints: {
        320: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        575: {
            slidesPerView: 1,
            // spaceBetween: 30,
        },
        767: {
            slidesPerView: 2,
            // spaceBetween: 30,
        },
        991: {
            slidesPerView: 2,
            // spaceBetween: 30,
        },
        1199: {
            slidesPerView: 2,
            // spaceBetween: 30,
        },
        1350: {
            slidesPerView: 3,
            // spaceBetween: 30,
        },
    }



}




export default function About() {
    const [isOpen, setOpen] = useState(false)
    const [activeIndex, setActiveIndex] = useState(1)
    const handleOnClick = (index) => {
        setActiveIndex(index)
    }
    return (
        <>
        <Layout headerStyle={3} footerStyle={1} breadcrumbTitle="About company">
        {/*About One Start */}
        <section className="about-one">
            <div className="container">
                <div className="row">
                    <div className="col-xl-6">
                        <div className="about-one__left">
                            <div className="about-one__img-box wow slideInLeft" data-wow-delay="100ms"
                                data-wow-duration="2500ms">
                                <div className="about-one__img">
                                    <img src="assets/images/resources/about-one-img-1.jpg" alt=""/>
                                </div>
                                <div className="about-one__happy-client">
                                    <div className="about-one__happy-client-inner">
                                        <div className="about-one__happy-client-count count-box">
                                            <h3>3000</h3>
                                            <span className="about-one__happy-client-plus">+</span>
                                        </div>
                                        <p className="about-one__happy-client-text">Happy</p>
                                    </div>
                                    <p className="about-one__happy-client-text-2">Clients</p>
                                </div>
                                <div className="about-one__experience">
                                    <div className="about-one__experience-count count-box">
                                        <h3>15</h3>
                                        <span className="about-one__experience-plus">+</span>
                                    </div>
                                    <p className="about-one__experience-text">YEARS OF EXPERIENCE</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-xl-6">
                        <div className="about-one__right">
                            <div className="section-title text-left">
                                <div className="section-title__tagline-box">
                                    <span className="section-title__tagline">about us</span>
                                </div>
                                <h2 className="section-title__title">Protecting you is our top priority system</h2>
                            </div>
                            <p className="about-one__text">A specialized military unit tasked with gathering information and
                                de conducting surveillance in high-risk or enemy territory. A vigilant wa military team
                                responsible for monitoring</p>
                            <div className="about-one__points-box">
                                <ul className="about-one__points-list list-unstyled">
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Top Guard</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Cyber Shield</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Peace Mind</p>
                                    </li>
                                </ul>
                                <ul className="about-one__points-list about-one__points-list-2 list-unstyled">
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Threat Defense</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Digital Fortres</p>
                                    </li>
                                    <li>
                                        <div className="icon">
                                            <span className="icon-check"></span>
                                        </div>
                                        <p>Cyber Power</p>
                                    </li>
                                </ul>
                            </div>
                            <p className="about-one__text-2">A specialized military unit tasked with gathering information
                                and conducting surveillance in high-risk </p>
                            <div className="about-one__btn-box">
                                <Link href="about" className="about-one__btn thm-btn">Discover More<span
                                        className="icon-plus"></span></Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        {/*About One End */}

        {/*Feature One Start */}
        <section className="feature-one">
            <div className="container">
                <div className="section-title text-left">
                    <div className="section-title__tagline-box">
                        <span className="section-title__tagline">features</span>
                    </div>
                    <h2 className="section-title__title">Guarding your digital fortress is<br/> our responsibility</h2>
                </div>
                <div className="feature-one__inner tabs-box">
                    <div className="feature-one__tab-box clearfix">
                        <ul className="tab-buttons clearfix list-unstyled">
                        <li className={activeIndex == 1 ? "tab-btn active-btn" : "tab-btn"} onClick={() => handleOnClick(1)}>
                                <div className="feature-one__tab-btn">
                                    <span>Racidential</span>
                                </div>
                            </li>
                            <li className={activeIndex == 2 ? "tab-btn active-btn" : "tab-btn"} onClick={() => handleOnClick(2)}>
                                <div className="feature-one__tab-btn feature-one__tab-btn-2">
                                    <span>Commercial</span>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div className="feature-one__bottom">
                        <div className="tabs-content">
                            {/*tab*/}
                            <div className={activeIndex == 1 ? "tab fadeInUp animated show active-tab" : "tab fadeInUp animated"}>
                                <ul className="feature-one__feature-list list-unstyled">
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-ip-camera"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">IP
                                                    <br/>Camera</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-vision"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Night
                                                    Vision<br/> Mode</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-data-guard"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Data Sync<br/>
                                                    Guard</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-motion"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Full
                                                    Motion<br/> Capture</Link></h3>
                                        </div>
                                    </li>
                                </ul>
                                <ul className="feature-one__feature-list list-unstyled">
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-sunglass"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Smart
                                                    <br/>Detector</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-okitok"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Trust
                                                    <br/>Secure</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-waterproof"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link
                                                    href="services-details">Waterproof<br/> System</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-backup-power"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Backup
                                                    <br/>power</Link></h3>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            {/*tab*/}
                            {/*tab*/}
                            <div className={activeIndex == 2 ? "tab fadeInUp animated show active-tab" : "tab fadeInUp animated"}>
                                <ul className="feature-one__feature-list list-unstyled">
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-ip-camera"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">IP
                                                    <br/>Camera</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-vision"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Night
                                                    Vision<br/> Mode</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-data-guard"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Data Sync<br/>
                                                    Guard</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-motion"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Full
                                                    Motion<br/> Capture</Link></h3>
                                        </div>
                                    </li>
                                </ul>
                                <ul className="feature-one__feature-list list-unstyled">
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-sunglass"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Smart
                                                    <br/>Detector</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-okitok"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Trust
                                                    <br/>Secure</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-waterproof"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link
                                                    href="services-details">Waterproof<br/> System</Link></h3>
                                        </div>
                                    </li>
                                    <li>
                                        <div className="feature-one__single">
                                            <div className="feature-one__icon">
                                                <span className="icon-backup-power"></span>
                                            </div>
                                            <h3 className="feature-one__title"><Link href="services-details">Backup
                                                    <br/>power</Link></h3>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            {/*tab*/}
                        </div>
                    </div>
                </div>
            </div>
        </section>
        {/*Feature One End */}

        {/*Storage One Start */}
        <section className="storage-one storage-two">
            <div className="container">
                <div className="section-title text-left">
                    <div className="section-title__tagline-box">
                        <span className="section-title__tagline">our Storage</span>
                    </div>
                    <h2 className="section-title__title">Ensuring your igital Threats<br/> protection From </h2>
                </div>
                <div className="storage-one__bottom">
                    <Swiper {...swiperOptions} className="storage-one__carousel owl-carousel owl-theme thm-owl__carousel">
                        {/*Storage One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="storage-one__single">
                                <div className="storage-one__img-box">
                                    <div className="storage-one__img">
                                        <img src="assets/images/storage/storage-1-1.jpg" alt=""/>
                                    </div>
                                    <div className="storage-one__content">
                                        <div className="storage-one__icon">
                                            <span className="icon-cloud"></span>
                                        </div>
                                        <h3 className="storage-one__title"><Link href="project-details">Cloud storage</Link>
                                        </h3>
                                        <p className="storage-one__text">A specialized military unit tasked with gathering
                                            information</p>
                                        <div className="storage-one__arrow">
                                            <Link href="project-details" className="icon-long-arrow-right"></Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Storage One Single End*/}
                        {/*Storage One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="storage-one__single">
                                <div className="storage-one__img-box">
                                    <div className="storage-one__img">
                                        <img src="assets/images/storage/storage-1-2.jpg" alt=""/>
                                    </div>
                                    <div className="storage-one__content">
                                        <div className="storage-one__icon">
                                            <span className="icon-cloud"></span>
                                        </div>
                                        <h3 className="storage-one__title"><Link href="project-details">Cloud storage</Link>
                                        </h3>
                                        <p className="storage-one__text">A specialized military unit tasked with gathering
                                            information</p>
                                        <div className="storage-one__arrow">
                                            <Link href="project-details" className="icon-long-arrow-right"></Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Storage One Single End*/}
                        {/*Storage One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="storage-one__single">
                                <div className="storage-one__img-box">
                                    <div className="storage-one__img">
                                        <img src="assets/images/storage/storage-1-3.jpg" alt=""/>
                                    </div>
                                    <div className="storage-one__content">
                                        <div className="storage-one__icon">
                                            <span className="icon-cloud"></span>
                                        </div>
                                        <h3 className="storage-one__title"><Link href="project-details">Cloud storage</Link>
                                        </h3>
                                        <p className="storage-one__text">A specialized military unit tasked with gathering
                                            information</p>
                                        <div className="storage-one__arrow">
                                            <Link href="project-details" className="icon-long-arrow-right"></Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Storage One Single End*/}
                        {/*Storage One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="storage-one__single">
                                <div className="storage-one__img-box">
                                    <div className="storage-one__img">
                                        <img src="assets/images/storage/storage-1-4.jpg" alt=""/>
                                    </div>
                                    <div className="storage-one__content">
                                        <div className="storage-one__icon">
                                            <span className="icon-cloud"></span>
                                        </div>
                                        <h3 className="storage-one__title"><Link href="project-details">Cloud storage</Link>
                                        </h3>
                                        <p className="storage-one__text">A specialized military unit tasked with gathering
                                            information</p>
                                        <div className="storage-one__arrow">
                                            <Link href="project-details" className="icon-long-arrow-right"></Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Storage One Single End*/}
                        {/*Storage One Single Start*/}
                        <SwiperSlide>
                        <div className="item">
                            <div className="storage-one__single">
                                <div className="storage-one__img-box">
                                    <div className="storage-one__img">
                                        <img src="assets/images/storage/storage-1-5.jpg" alt=""/>
                                    </div>
                                    <div className="storage-one__content">
                                        <div className="storage-one__icon">
                                            <span className="icon-cloud"></span>
                                        </div>
                                        <h3 className="storage-one__title"><Link href="project-details">Cloud storage</Link>
                                        </h3>
                                        <p className="storage-one__text">A specialized military unit tasked with gathering
                                            information</p>
                                        <div className="storage-one__arrow">
                                            <Link href="project-details" className="icon-long-arrow-right"></Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </SwiperSlide>
                        {/*Storage One Single End*/}
                    </Swiper>
                </div>
                <p className="storage-one__bottom-text">Ensuring your digital protection a secure environment<Link
                        href="project">Get
                        started<span className="icon-arrow-up"></span></Link></p>
            </div>
        </section>
        {/*Storage One End */}

        {/*Process One Start */}
        <section className="process-one">
            <div className="container">
                <div className="row">
                    <div className="col-xl-6">
                        <div className="process-one__left">
                            <div className="section-title text-left">
                                <div className="section-title__tagline-box">
                                    <span className="section-title__tagline">Work Process</span>
                                </div>
                                <h2 className="section-title__title">Securing your peace of mind is our top priority</h2>
                            </div>
                            <p className="process-one__text-1">A specialized military unit tasked with gathering information
                                and conducting surveillance in high-risk </p>
                            <ul className="process-one__process-list list-unstyled">
                                <li className="wow fadeInLeft" data-wow-delay="100ms">
                                    <div className="process-one__count"></div>
                                    <div className="icon">
                                        <span className="icon-peace-mind"></span>
                                    </div>
                                    <h3><Link href="about">Peace Mind</Link></h3>
                                </li>
                                <li className="wow fadeInLeft" data-wow-delay="300ms">
                                    <div className="process-one__count"></div>
                                    <div className="icon">
                                        <span className="icon-shoes"></span>
                                    </div>
                                    <h3><Link href="about">Threat Defense</Link></h3>
                                </li>
                                <li className="wow fadeInLeft" data-wow-delay="600ms">
                                    <div className="process-one__count"></div>
                                    <div className="icon">
                                        <span className="icon-emil-2"></span>
                                    </div>
                                    <h3><Link href="about">Digital Fortress</Link></h3>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div className="col-xl-6">
                        <div className="process-one__right wow slideInRight" data-wow-delay="100ms"
                            data-wow-duration="2500ms">
                            <div className="row">
                                <div className="col-xl-6 col-lg-6 col-md-6">
                                    <div className="process-one__img-box">
                                        <div className="process-one__img">
                                            <img src="assets/images/resources/process-one-img-1.jpg" alt=""/>
                                        </div>
                                        <div className="process-one__count-box">
                                            <p className="process-one__count-text">Trusted By</p>
                                            <div className="process-one__count-2 count-box">
                                                <h3> 10</h3>
                                                <span className="process-one__count-plus">k</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-xl-6 col-lg-6 col-md-6">
                                    <div className="process-one__img-box-2">
                                        <div className="process-one__img-2">
                                            <img src="assets/images/resources/process-one-img-2.jpg" alt=""/>
                                        </div>
                                        <div className="process-one__img-3">
                                            <img src="assets/images/resources/process-one-img-3.jpg" alt=""/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        {/*Process One End */}

        {/*Message One Start */}
        <section className="message-one">
            <div className="message-one__bg"  style={{ backgroundImage: 'url(assets/images/backgrounds/message-one-bg.jpg)' }} >
            </div>
            <div className="container">
                <div className="section-title text-center">
                    <div className="section-title__tagline-box">
                        <span className="section-title__tagline">message us</span>
                    </div>
                    <h2 className="section-title__title">Keeping you one step ahead<br/> of threats</h2>
                </div>
                <div className="message-one__inner">
                    <div className="row">
                        {/*Message One Single Start*/}
                        <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                            <div className="message-one__single">
                                <div className="message-one__icon">
                                    <span className="icon-cup"></span>
                                </div>
                                <h3 className="message-one__title"><Link href="about">Level Up</Link></h3>
                            </div>
                        </div>
                        {/*Message One Single End*/}
                        {/*Message One Single Start*/}
                        <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                            <div className="message-one__single">
                                <div className="message-one__icon">
                                    <span className="icon-online-secure"></span>
                                </div>
                                <h3 className="message-one__title"><Link href="about">Online Secure</Link></h3>
                            </div>
                        </div>
                        {/*Message One Single End*/}
                        {/*Message One Single Start*/}
                        <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="600ms">
                            <div className="message-one__single">
                                <div className="message-one__icon">
                                    <span className="icon-safety"></span>
                                </div>
                                <h3 className="message-one__title"><Link href="about">Safety Respons</Link></h3>
                            </div>
                        </div>
                        {/*Message One Single End*/}
                        {/*Message One Single Start*/}
                        <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="900ms">
                            <div className="message-one__single">
                                <div className="message-one__icon">
                                    <span className="icon-threat"></span>
                                </div>
                                <h3 className="message-one__title"><Link href="about">Threat Ahead</Link></h3>
                            </div>
                        </div>
                        {/*Message One Single End*/}
                        {/*Message One Single Start*/}
                        <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="1200ms">
                            <div className="message-one__single">
                                <div className="message-one__icon">
                                    <span className="icon-man"></span>
                                </div>
                                <h3 className="message-one__title"><Link href="about">Trust Secure</Link></h3>
                            </div>
                        </div>
                        {/*Message One Single End*/}
                        {/*Message One Single Start*/}
                        <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="1500ms">
                            <div className="message-one__single">
                                <div className="message-one__icon">
                                    <span className="icon-bottol"></span>
                                </div>
                                <h3 className="message-one__title"><Link href="about">Digital Pro</Link></h3>
                            </div>
                        </div>
                        {/*Message One Single End*/}
                    </div>
                    <div className="message-one__bottom">
                        <form className="message-one__form mc-form" data-url="MC_FORM_URL">
                            <div className="message-one__form-input-box">
                                <input type="text" placeholder="Enter you ptoduct..." name="text"/>
                                <button type="submit" className="message-one__btn thm-btn">Discover More<span
                                        className="icon-plus"></span></button>
                            </div>
                        </form>
                        <div className="mc-form__response"></div>
                        <p className="message-one__bottom-text">Ensuring your digital protection a secure environment<Link
                                href="contact">Get started<span className="icon-arrow-up"></span></Link></p>
                    </div>
                </div>
            </div>
        </section>
        {/*Message One End */}

        {/*Pricing One Start */}
        <section className="pricing-one">
            <div className="container">
                <div className="pricing-one__top">
                    <div className="row">
                        <div className="col-xl-7">
                            <div className="section-title text-left">
                                <div className="section-title__tagline-box">
                                    <span className="section-title__tagline">Best Pricing</span>
                                </div>
                                <h2 className="section-title__title">aking security to the<br/> next level</h2>
                            </div>
                        </div>
                        <div className="col-xl-5">
                            <p className="pricing-one__top-text">A specialized military unit tasked with gathering
                                information<br/> and conducting surveillance in high-risk </p>
                        </div>
                    </div>
                </div>
                <div className="row">
                    {/*Pricing Ine Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="100ms">
                        <div className="pricing-one__single">
                            <div className="pricing-one__icon">
                                <span className="icon-seaech-1"></span>
                            </div>
                            <h3 className="pricing-one__title">Starter plan</h3>
                            <h3 className="pricing-one__price">$19<span>/mo</span></h3>
                            <ul className="pricing-one__points list-unstyled">
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>IP Camera</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Night Vision Mode</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Data Guard</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Full Motion Capture</p>
                                </li>
                            </ul>
                            <div className="pricing-one__btn-box">
                                <Link href="contact" className="pricing-one__btn thm-btn">Discover More<span
                                        className="icon-plus"></span></Link>
                            </div>
                        </div>
                    </div>
                    {/*Pricing Ine Single End*/}
                    {/*Pricing Ine Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="300ms">
                        <div className="pricing-one__single">
                            <div className="pricing-one__icon">
                                <span className="icon-computer"></span>
                            </div>
                            <h3 className="pricing-one__title">Premium plan</h3>
                            <h3 className="pricing-one__price">$29<span>/mo</span></h3>
                            <ul className="pricing-one__points list-unstyled">
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>IP Camera</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Night Vision Mode</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Data Guard</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Full Motion Capture</p>
                                </li>
                            </ul>
                            <div className="pricing-one__btn-box">
                                <Link href="contact" className="pricing-one__btn thm-btn">Discover More<span
                                        className="icon-plus"></span></Link>
                            </div>
                        </div>
                    </div>
                    {/*Pricing Ine Single End*/}
                    {/*Pricing Ine Single Start*/}
                    <div className="col-xl-4 col-lg-4 wow fadeInUp" data-wow-delay="600ms">
                        <div className="pricing-one__single">
                            <div className="pricing-one__icon">
                                <span className="icon-love"></span>
                            </div>
                            <h3 className="pricing-one__title">Gold plan</h3>
                            <h3 className="pricing-one__price">$39<span>/mo</span></h3>
                            <ul className="pricing-one__points list-unstyled">
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>IP Camera</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Night Vision Mode</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Data Guard</p>
                                </li>
                                <li>
                                    <div className="icon">
                                        <span className="icon-check-2"></span>
                                    </div>
                                    <p>Full Motion Capture</p>
                                </li>
                            </ul>
                            <div className="pricing-one__btn-box">
                                <Link href="contact" className="pricing-one__btn thm-btn">Discover More<span
                                        className="icon-plus"></span></Link>
                            </div>
                        </div>
                    </div>
                    {/*Pricing Ine Single End*/}
                </div>
            </div>
        </section>
        {/*Pricing One End */}

        {/*Product One Start */}
        <section className="product-one product-two">
            <div className="container">
                <div className="row">
                    <div className="col-xl-6">
                        <div className="product-one__left">
                            <div className="section-title text-left">
                                <div className="section-title__tagline-box">
                                    <span className="section-title__tagline">Product</span>
                                </div>
                                <h2 className="section-title__title">Keeping you one step<br/> ahead of threats</h2>
                            </div>
                            <p className="product-one__text">A specialized military unit tasked with gathering information
                                and conducting surveillance in high-risk </p>
                            <div className="product-one__img">
                                <img src="assets/images/resources/product-one-img-1.jpg" alt=""/>
                            </div>
                        </div>
                    </div>
                    <div className="col-xl-6">
                        <div className="product-one__right wow slideInRight" data-wow-delay="100ms"
                            data-wow-duration="2500ms">
                            <form action="assets/inc/sendemail.php" className="product-one__form contact-form-validated">
                                <div className="product-one__single-list">
                                    <div className="select-box">
                                        <select className="wide">
                                            <option data-display="Camera Type*">Camera Type*</option>
                                            <option value="1">Sort by popular</option>
                                            <option value="2">Sort by Price</option>
                                            <option value="3">Sort by Ratings</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="product-one__single-list">
                                    <div className="select-box">
                                        <select className="wide">
                                            <option data-display="Storage Amount*">Storage Amount*</option>
                                            <option value="1">Sort by popular</option>
                                            <option value="2">Sort by Price</option>
                                            <option value="3">Sort by Ratings</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="product-one__single-list">
                                    <div className="select-box">
                                        <select className="wide">
                                            <option data-display="Piece">Piece</option>
                                            <option value="1">Sort by popular</option>
                                            <option value="2">Sort by Price</option>
                                            <option value="3">Sort by Ratings</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="product-one__single-list">
                                    <div className="select-box">
                                        <select className="wide">
                                            <option data-display="Pixel quality*">Pixel quality*</option>
                                            <option value="1">Sort by popular</option>
                                            <option value="2">Sort by Price</option>
                                            <option value="3">Sort by Ratings</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="product-one__btn-box">
                                    <button type="submit" className="thm-btn product-one__btn">BUY NOW<span
                                            className="icon-plus"></span></button>
                                </div>
                            </form>
                            <div className="result"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        {/*Product One End */}

        {/*Brand One Start*/}
        <section className="brand-one brand-two">
            <div className="container">
                <div className="brand-one__inner">
                    <BrandSlider/>
                </div>
            </div>
        </section>
        {/*Brand One End*/}


        {/*CTA One Start */}
        <section className="cta-one">
            <div className="container">
                <div className="cta-one__inner">
                    <div className="cta-one__bg"  style={{ backgroundImage: 'url(assets/images/backgrounds/cta-one-bg.jpg)' }} >
                    </div>
                    <div className="row">
                        <div className="col-xl-6 col-lg-6"></div>
                        <div className="col-xl-6 col-lg-6">
                            <div className="cta-one__right">
                                <h3 className="cta-one__title">Get Free Estimate</h3>
                                <p className="cta-one__text">Lorem Ipsum is simply is dumiomy is text Lorem Ipsum </p>
                                <form className="cta-one__form mc-form" data-url="MC_FORM_URL">
                                    <div className="cta-one__form-input-box">
                                        <input type="email" placeholder="Your email..." name="email"/>
                                        <button type="submit" className="cta-one__btn thm-btn">Login<span
                                                className="icon-plus"></span></button>
                                    </div>
                                </form>
                                <div className="mc-form__response"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        {/*CTA One End */}

            </Layout>
        </>
    )
}


