'use client'
import Link from "next/link"
import { useState } from "react"
import Layout from "@/components/layout/Layout"



export default function Home() {
    const [activeIndex, setActiveIndex] = useState(1)
    const handleOnClick = (index) => {
        setActiveIndex(index)
    }

    return (
        <>
            <Layout headerStyle={3} footerStyle={1} breadcrumbTitle="Service Details">
        <div>
        {/*Services Details Start*/}
        <section className="services-details">
            <div className="container">
                <h3 className="services-details__top-title">Service lists</h3>
                <div className="services-details__inner tabs-box">
                    <div className="services-details__tab-box clearfix">
                        <ul className="tab-buttons clearfix list-unstyled">
                        <li className={activeIndex == 1 ? "tab-btn active-btn" : "tab-btn"} onClick={() => handleOnClick(1)}>
                                <div className="services-details__tab-btn">
                                    <span>ALL</span>
                                </div>
                            </li>
                            <li className={activeIndex == 2 ? "tab-btn active-btn" : "tab-btn"} onClick={() => handleOnClick(2)}>
                                <div className="services-details__tab-btn">
                                    <span>Security Camera</span>
                                </div>
                            </li>
                            <li className={activeIndex == 3 ? "tab-btn active-btn" : "tab-btn"} onClick={() => handleOnClick(3)}>
                                <div className="services-details__tab-btn">
                                    <span>Control Camera</span>
                                </div>
                            </li>
                            <li className={activeIndex == 4 ? "tab-btn active-btn" : "tab-btn"} onClick={() => handleOnClick(4)}>
                                <div className="services-details__tab-btn">
                                    <span>Control app</span>
                                </div>
                            </li>
                            <li className={activeIndex == 5 ? "tab-btn active-btn" : "tab-btn"} onClick={() => handleOnClick(5)}>
                                <div className="services-details__tab-btn">
                                    <span>Ip Camera</span>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div className="services-details__bottom">
                        <div className="tabs-content">
                            {/*tab*/}
                            <div className={activeIndex == 1 ? "tab fadeInUp animated show active-tab" : "tab fadeInUp animated"}>
                                <div className="row">
                                    <div className="col-xl-8 col-lg-7">
                                        <div className="services-details__left">
                                            <div className="services-details__img-1">
                                                <img src="assets/images/services/services-details-img-1.jpg" alt=""/>
                                                <div className="services-details__icon">
                                                    <span className="icon-watch"></span>
                                                </div>
                                            </div>
                                            <h3 className="services-details__title-1">Cyber Fighter</h3>
                                            <p className="services-details__text">Distracted by the readable content of a
                                                page when looking at its layout io The point of using Lorem Ipsum is
                                                that it has a more-iso or-less normal distribution of letters, as
                                                opposed to using It is is a long established to th fact that anni reader
                                                will be distracted by the readable content</p>
                                            <div className="services-details__points-box">
                                                <ul className="services-details__points list-unstyled">
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>CCTV installation</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>CCTV repair</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>Surveillance camera</p>
                                                    </li>
                                                </ul>
                                                <ul
                                                    className="services-details__points services-details__points-2 list-unstyled">
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>Surveillance setup</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>System integration</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>Motion detection</p>
                                                    </li>
                                                </ul>
                                            </div>
                                            <p className="services-details__text">Distracted by the readable content of a
                                                page when looking at its layout io The point of using Lorem Ipsum is
                                                that it has a more- or-less normal distribution of letters</p>
                                            <p className="services-details__text services-details__text-3">Distracted by the
                                                readable content of a
                                                page when loDistracted by the readable content of a page when looking at
                                                its layout io The point of using Lorem Ipsum is that it has a more-iso
                                                or-less normal distribution of letters, as opposed to using It is is a
                                                long established to th fact that anni reader will be distracted by the
                                                readable contentDistracted by the readable content of a page when
                                                looking at its layout io The point of using Lorem Ipsum is that it has a
                                                more-iso or-less normal distribution of letters, as opposed to using It
                                                is is a long established to th fact that anni reader will be distracted
                                                by the readable contento</p>
                                            <h3 className="services-details__title-2">Securing your peace </h3>
                                            <p className="services-details__text services-details__text-4">A specialized
                                                military unit tasked with gathering information and <br/>conducting
                                                surveillance in high-risk </p>
                                            <ul className="process-one__process-list list-unstyled">
                                                <li>
                                                    <div className="process-one__count"></div>
                                                    <div className="icon">
                                                        <span className="icon-peace-mind"></span>
                                                    </div>
                                                    <h3><Link href="about">Peace Mind</Link></h3>
                                                </li>
                                                <li>
                                                    <div className="process-one__count"></div>
                                                    <div className="icon">
                                                        <span className="icon-shoes"></span>
                                                    </div>
                                                    <h3><Link href="about">Threat Defense</Link></h3>
                                                </li>
                                                <li>
                                                    <div className="process-one__count"></div>
                                                    <div className="icon">
                                                        <span className="icon-emil-2"></span>
                                                    </div>
                                                    <h3><Link href="about">Digital Fortress</Link></h3>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="col-xl-4 col-lg-5">
                                        <div className="services-details__right">
                                            <div className="services-details__popular-services">
                                                <h3 className="services-details__popular-services-title">Popular Services
                                                </h3>
                                                <ul className="services-details__popular-services-list list-unstyled">
                                                    <li>
                                                        <div className="services-details__popular-services-img">
                                                            <img src="assets/images/services/services-lp-1-1.jpg"
                                                                alt=""/>
                                                        </div>
                                                        <div className="services-details__popular-services-content">
                                                            <p className="services-details__popular-services-date"><span
                                                                    className="icon-calender"></span>October 19, 2023</p>
                                                            <h3><Link href="#">Connect Innovate Succeed the design</Link></h3>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="services-details__popular-services-img">
                                                            <img src="assets/images/services/services-lp-1-2.jpg"
                                                                alt=""/>
                                                        </div>
                                                        <div className="services-details__popular-services-content">
                                                            <p className="services-details__popular-services-date"><span
                                                                    className="icon-calender"></span>October 19, 2023</p>
                                                            <h3><Link href="#">Elevate Your Business with IT the most</Link>
                                                            </h3>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="services-details__popular-services-img">
                                                            <img src="assets/images/services/services-lp-1-3.jpg"
                                                                alt=""/>
                                                        </div>
                                                        <div className="services-details__popular-services-content">
                                                            <p className="services-details__popular-services-date"><span
                                                                    className="icon-calender"></span>October 19, 2023</p>
                                                            <h3><Link href="#">Simplify IT for Enhanced Productivity</Link>
                                                            </h3>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div className="services-details__get-in-touch">
                                                <h3 className="services-details__popular-services-title">Get in Touch
                                                </h3>
                                                <ul className="services-details__get-in-touch-list list-unstyled">
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-call"></span>
                                                        </div>
                                                        <p><Link href="tel:+888123456765">(+888) 123 456 765</Link></p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-email"></span>
                                                        </div>
                                                        <p><Link href="mailto:infoname@mail.com">infoname@mail.com</Link></p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-clock"></span>
                                                        </div>
                                                        <p>Mon-Sun : 9AM-5PM</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-pin"></span>
                                                        </div>
                                                        <p>4140 Parker Rd. Allentown, New Mexico 31134</p>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/*tab*/}
                            {/*tab*/}
                            <div className={activeIndex == 2 ? "tab fadeInUp animated show active-tab" : "tab fadeInUp animated"}>
                                <div className="row">
                                    <div className="col-xl-8 col-lg-7">
                                        <div className="services-details__left">
                                            <div className="services-details__img-1">
                                                <img src="assets/images/services/services-details-img-2.jpg" alt=""/>
                                                <div className="services-details__icon">
                                                    <span className="icon-watch"></span>
                                                </div>
                                            </div>
                                            <h3 className="services-details__title-1">Security Camera</h3>
                                            <p className="services-details__text">Distracted by the readable content of a
                                                page when looking at its layout io The point of using Lorem Ipsum is
                                                that it has a more-iso or-less normal distribution of letters, as
                                                opposed to using It is is a long established to th fact that anni reader
                                                will be distracted by the readable content</p>
                                            <div className="services-details__points-box">
                                                <ul className="services-details__points list-unstyled">
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>CCTV installation</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>CCTV repair</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>Surveillance camera</p>
                                                    </li>
                                                </ul>
                                                <ul
                                                    className="services-details__points services-details__points-2 list-unstyled">
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>Surveillance setup</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>System integration</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>Motion detection</p>
                                                    </li>
                                                </ul>
                                            </div>
                                            <p className="services-details__text">Distracted by the readable content of a
                                                page when looking at its layout io The point of using Lorem Ipsum is
                                                that it has a more- or-less normal distribution of letters</p>
                                            <p className="services-details__text services-details__text-3">Distracted by the
                                                readable content of a
                                                page when loDistracted by the readable content of a page when looking at
                                                its layout io The point of using Lorem Ipsum is that it has a more-iso
                                                or-less normal distribution of letters, as opposed to using It is is a
                                                long established to th fact that anni reader will be distracted by the
                                                readable contentDistracted by the readable content of a page when
                                                looking at its layout io The point of using Lorem Ipsum is that it has a
                                                more-iso or-less normal distribution of letters, as opposed to using It
                                                is is a long established to th fact that anni reader will be distracted
                                                by the readable contento</p>
                                            <h3 className="services-details__title-2">Securing your peace </h3>
                                            <p className="services-details__text services-details__text-4">A specialized
                                                military unit tasked with gathering information and <br/>conducting
                                                surveillance in high-risk </p>
                                            <ul className="process-one__process-list list-unstyled">
                                                <li>
                                                    <div className="process-one__count"></div>
                                                    <div className="icon">
                                                        <span className="icon-peace-mind"></span>
                                                    </div>
                                                    <h3><Link href="about">Peace Mind</Link></h3>
                                                </li>
                                                <li>
                                                    <div className="process-one__count"></div>
                                                    <div className="icon">
                                                        <span className="icon-shoes"></span>
                                                    </div>
                                                    <h3><Link href="about">Threat Defense</Link></h3>
                                                </li>
                                                <li>
                                                    <div className="process-one__count"></div>
                                                    <div className="icon">
                                                        <span className="icon-emil-2"></span>
                                                    </div>
                                                    <h3><Link href="about">Digital Fortress</Link></h3>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="col-xl-4 col-lg-5">
                                        <div className="services-details__right">
                                            <div className="services-details__popular-services">
                                                <h3 className="services-details__popular-services-title">Popular Services
                                                </h3>
                                                <ul className="services-details__popular-services-list list-unstyled">
                                                    <li>
                                                        <div className="services-details__popular-services-img">
                                                            <img src="assets/images/services/services-lp-1-1.jpg"
                                                                alt=""/>
                                                        </div>
                                                        <div className="services-details__popular-services-content">
                                                            <p className="services-details__popular-services-date"><span
                                                                    className="icon-calender"></span>October 19, 2023</p>
                                                            <h3><Link href="#">Connect Innovate Succeed the design</Link></h3>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="services-details__popular-services-img">
                                                            <img src="assets/images/services/services-lp-1-2.jpg"
                                                                alt=""/>
                                                        </div>
                                                        <div className="services-details__popular-services-content">
                                                            <p className="services-details__popular-services-date"><span
                                                                    className="icon-calender"></span>October 19, 2023</p>
                                                            <h3><Link href="#">Elevate Your Business with IT the most</Link>
                                                            </h3>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="services-details__popular-services-img">
                                                            <img src="assets/images/services/services-lp-1-3.jpg"
                                                                alt=""/>
                                                        </div>
                                                        <div className="services-details__popular-services-content">
                                                            <p className="services-details__popular-services-date"><span
                                                                    className="icon-calender"></span>October 19, 2023</p>
                                                            <h3><Link href="#">Simplify IT for Enhanced Productivity</Link>
                                                            </h3>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div className="services-details__get-in-touch">
                                                <h3 className="services-details__popular-services-title">Get in Touch
                                                </h3>
                                                <ul className="services-details__get-in-touch-list list-unstyled">
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-call"></span>
                                                        </div>
                                                        <p><Link href="tel:+888123456765">(+888) 123 456 765</Link></p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-email"></span>
                                                        </div>
                                                        <p><Link href="mailto:infoname@mail.com">infoname@mail.com</Link></p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-clock"></span>
                                                        </div>
                                                        <p>Mon-Sun : 9AM-5PM</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-pin"></span>
                                                        </div>
                                                        <p>4140 Parker Rd. Allentown, New Mexico 31134</p>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/*tab*/}
                            {/*tab*/}
                            <div className={activeIndex == 3 ? "tab fadeInUp animated show active-tab" : "tab fadeInUp animated"}>
                                <div className="row">
                                    <div className="col-xl-8 col-lg-7">
                                        <div className="services-details__left">
                                            <div className="services-details__img-1">
                                                <img src="assets/images/services/services-details-img-3.jpg" alt=""/>
                                                <div className="services-details__icon">
                                                    <span className="icon-watch"></span>
                                                </div>
                                            </div>
                                            <h3 className="services-details__title-1">Control Camera</h3>
                                            <p className="services-details__text">Distracted by the readable content of a
                                                page when looking at its layout io The point of using Lorem Ipsum is
                                                that it has a more-iso or-less normal distribution of letters, as
                                                opposed to using It is is a long established to th fact that anni reader
                                                will be distracted by the readable content</p>
                                            <div className="services-details__points-box">
                                                <ul className="services-details__points list-unstyled">
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>CCTV installation</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>CCTV repair</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>Surveillance camera</p>
                                                    </li>
                                                </ul>
                                                <ul
                                                    className="services-details__points services-details__points-2 list-unstyled">
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>Surveillance setup</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>System integration</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>Motion detection</p>
                                                    </li>
                                                </ul>
                                            </div>
                                            <p className="services-details__text">Distracted by the readable content of a
                                                page when looking at its layout io The point of using Lorem Ipsum is
                                                that it has a more- or-less normal distribution of letters</p>
                                            <p className="services-details__text services-details__text-3">Distracted by the
                                                readable content of a
                                                page when loDistracted by the readable content of a page when looking at
                                                its layout io The point of using Lorem Ipsum is that it has a more-iso
                                                or-less normal distribution of letters, as opposed to using It is is a
                                                long established to th fact that anni reader will be distracted by the
                                                readable contentDistracted by the readable content of a page when
                                                looking at its layout io The point of using Lorem Ipsum is that it has a
                                                more-iso or-less normal distribution of letters, as opposed to using It
                                                is is a long established to th fact that anni reader will be distracted
                                                by the readable contento</p>
                                            <h3 className="services-details__title-2">Securing your peace </h3>
                                            <p className="services-details__text services-details__text-4">A specialized
                                                military unit tasked with gathering information and <br/>conducting
                                                surveillance in high-risk </p>
                                            <ul className="process-one__process-list list-unstyled">
                                                <li>
                                                    <div className="process-one__count"></div>
                                                    <div className="icon">
                                                        <span className="icon-peace-mind"></span>
                                                    </div>
                                                    <h3><Link href="about">Peace Mind</Link></h3>
                                                </li>
                                                <li>
                                                    <div className="process-one__count"></div>
                                                    <div className="icon">
                                                        <span className="icon-shoes"></span>
                                                    </div>
                                                    <h3><Link href="about">Threat Defense</Link></h3>
                                                </li>
                                                <li>
                                                    <div className="process-one__count"></div>
                                                    <div className="icon">
                                                        <span className="icon-emil-2"></span>
                                                    </div>
                                                    <h3><Link href="about">Digital Fortress</Link></h3>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="col-xl-4 col-lg-5">
                                        <div className="services-details__right">
                                            <div className="services-details__popular-services">
                                                <h3 className="services-details__popular-services-title">Popular Services
                                                </h3>
                                                <ul className="services-details__popular-services-list list-unstyled">
                                                    <li>
                                                        <div className="services-details__popular-services-img">
                                                            <img src="assets/images/services/services-lp-1-1.jpg"
                                                                alt=""/>
                                                        </div>
                                                        <div className="services-details__popular-services-content">
                                                            <p className="services-details__popular-services-date"><span
                                                                    className="icon-calender"></span>October 19, 2023</p>
                                                            <h3><Link href="#">Connect Innovate Succeed the design</Link></h3>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="services-details__popular-services-img">
                                                            <img src="assets/images/services/services-lp-1-2.jpg"
                                                                alt=""/>
                                                        </div>
                                                        <div className="services-details__popular-services-content">
                                                            <p className="services-details__popular-services-date"><span
                                                                    className="icon-calender"></span>October 19, 2023</p>
                                                            <h3><Link href="#">Elevate Your Business with IT the most</Link>
                                                            </h3>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="services-details__popular-services-img">
                                                            <img src="assets/images/services/services-lp-1-3.jpg"
                                                                alt=""/>
                                                        </div>
                                                        <div className="services-details__popular-services-content">
                                                            <p className="services-details__popular-services-date"><span
                                                                    className="icon-calender"></span>October 19, 2023</p>
                                                            <h3><Link href="#">Simplify IT for Enhanced Productivity</Link>
                                                            </h3>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div className="services-details__get-in-touch">
                                                <h3 className="services-details__popular-services-title">Get in Touch
                                                </h3>
                                                <ul className="services-details__get-in-touch-list list-unstyled">
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-call"></span>
                                                        </div>
                                                        <p><Link href="tel:+888123456765">(+888) 123 456 765</Link></p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-email"></span>
                                                        </div>
                                                        <p><Link href="mailto:infoname@mail.com">infoname@mail.com</Link></p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-clock"></span>
                                                        </div>
                                                        <p>Mon-Sun : 9AM-5PM</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-pin"></span>
                                                        </div>
                                                        <p>4140 Parker Rd. Allentown, New Mexico 31134</p>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/*tab*/}
                            {/*tab*/}
                            <div className={activeIndex == 4 ? "tab fadeInUp animated show active-tab" : "tab fadeInUp animated"}>
                                <div className="row">
                                    <div className="col-xl-8 col-lg-7">
                                        <div className="services-details__left">
                                            <div className="services-details__img-1">
                                                <img src="assets/images/services/services-details-img-4.jpg" alt=""/>
                                                <div className="services-details__icon">
                                                    <span className="icon-watch"></span>
                                                </div>
                                            </div>
                                            <h3 className="services-details__title-1">Control app</h3>
                                            <p className="services-details__text">Distracted by the readable content of a
                                                page when looking at its layout io The point of using Lorem Ipsum is
                                                that it has a more-iso or-less normal distribution of letters, as
                                                opposed to using It is is a long established to th fact that anni reader
                                                will be distracted by the readable content</p>
                                            <div className="services-details__points-box">
                                                <ul className="services-details__points list-unstyled">
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>CCTV installation</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>CCTV repair</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>Surveillance camera</p>
                                                    </li>
                                                </ul>
                                                <ul
                                                    className="services-details__points services-details__points-2 list-unstyled">
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>Surveillance setup</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>System integration</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>Motion detection</p>
                                                    </li>
                                                </ul>
                                            </div>
                                            <p className="services-details__text">Distracted by the readable content of a
                                                page when looking at its layout io The point of using Lorem Ipsum is
                                                that it has a more- or-less normal distribution of letters</p>
                                            <p className="services-details__text services-details__text-3">Distracted by the
                                                readable content of a
                                                page when loDistracted by the readable content of a page when looking at
                                                its layout io The point of using Lorem Ipsum is that it has a more-iso
                                                or-less normal distribution of letters, as opposed to using It is is a
                                                long established to th fact that anni reader will be distracted by the
                                                readable contentDistracted by the readable content of a page when
                                                looking at its layout io The point of using Lorem Ipsum is that it has a
                                                more-iso or-less normal distribution of letters, as opposed to using It
                                                is is a long established to th fact that anni reader will be distracted
                                                by the readable contento</p>
                                            <h3 className="services-details__title-2">Securing your peace </h3>
                                            <p className="services-details__text services-details__text-4">A specialized
                                                military unit tasked with gathering information and <br/>conducting
                                                surveillance in high-risk </p>
                                            <ul className="process-one__process-list list-unstyled">
                                                <li>
                                                    <div className="process-one__count"></div>
                                                    <div className="icon">
                                                        <span className="icon-peace-mind"></span>
                                                    </div>
                                                    <h3><Link href="about">Peace Mind</Link></h3>
                                                </li>
                                                <li>
                                                    <div className="process-one__count"></div>
                                                    <div className="icon">
                                                        <span className="icon-shoes"></span>
                                                    </div>
                                                    <h3><Link href="about">Threat Defense</Link></h3>
                                                </li>
                                                <li>
                                                    <div className="process-one__count"></div>
                                                    <div className="icon">
                                                        <span className="icon-emil-2"></span>
                                                    </div>
                                                    <h3><Link href="about">Digital Fortress</Link></h3>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="col-xl-4 col-lg-5">
                                        <div className="services-details__right">
                                            <div className="services-details__popular-services">
                                                <h3 className="services-details__popular-services-title">Popular Services
                                                </h3>
                                                <ul className="services-details__popular-services-list list-unstyled">
                                                    <li>
                                                        <div className="services-details__popular-services-img">
                                                            <img src="assets/images/services/services-lp-1-1.jpg"
                                                                alt=""/>
                                                        </div>
                                                        <div className="services-details__popular-services-content">
                                                            <p className="services-details__popular-services-date"><span
                                                                    className="icon-calender"></span>October 19, 2023</p>
                                                            <h3><Link href="#">Connect Innovate Succeed the design</Link></h3>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="services-details__popular-services-img">
                                                            <img src="assets/images/services/services-lp-1-2.jpg"
                                                                alt=""/>
                                                        </div>
                                                        <div className="services-details__popular-services-content">
                                                            <p className="services-details__popular-services-date"><span
                                                                    className="icon-calender"></span>October 19, 2023</p>
                                                            <h3><Link href="#">Elevate Your Business with IT the most</Link>
                                                            </h3>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="services-details__popular-services-img">
                                                            <img src="assets/images/services/services-lp-1-3.jpg"
                                                                alt=""/>
                                                        </div>
                                                        <div className="services-details__popular-services-content">
                                                            <p className="services-details__popular-services-date"><span
                                                                    className="icon-calender"></span>October 19, 2023</p>
                                                            <h3><Link href="#">Simplify IT for Enhanced Productivity</Link>
                                                            </h3>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div className="services-details__get-in-touch">
                                                <h3 className="services-details__popular-services-title">Get in Touch
                                                </h3>
                                                <ul className="services-details__get-in-touch-list list-unstyled">
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-call"></span>
                                                        </div>
                                                        <p><Link href="tel:+888123456765">(+888) 123 456 765</Link></p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-email"></span>
                                                        </div>
                                                        <p><Link href="mailto:infoname@mail.com">infoname@mail.com</Link></p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-clock"></span>
                                                        </div>
                                                        <p>Mon-Sun : 9AM-5PM</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-pin"></span>
                                                        </div>
                                                        <p>4140 Parker Rd. Allentown, New Mexico 31134</p>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/*tab*/}
                            {/*tab*/}
                            <div className={activeIndex == 5 ? "tab fadeInUp animated show active-tab" : "tab fadeInUp animated"}>
                                <div className="row">
                                    <div className="col-xl-8 col-lg-7">
                                        <div className="services-details__left">
                                            <div className="services-details__img-1">
                                                <img src="assets/images/services/services-details-img-5.jpg" alt=""/>
                                                <div className="services-details__icon">
                                                    <span className="icon-watch"></span>
                                                </div>
                                            </div>
                                            <h3 className="services-details__title-1">Ip Camera</h3>
                                            <p className="services-details__text">Distracted by the readable content of a
                                                page when looking at its layout io The point of using Lorem Ipsum is
                                                that it has a more-iso or-less normal distribution of letters, as
                                                opposed to using It is is a long established to th fact that anni reader
                                                will be distracted by the readable content</p>
                                            <div className="services-details__points-box">
                                                <ul className="services-details__points list-unstyled">
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>CCTV installation</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>CCTV repair</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>Surveillance camera</p>
                                                    </li>
                                                </ul>
                                                <ul
                                                    className="services-details__points services-details__points-2 list-unstyled">
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>Surveillance setup</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>System integration</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-check-2"></span>
                                                        </div>
                                                        <p>Motion detection</p>
                                                    </li>
                                                </ul>
                                            </div>
                                            <p className="services-details__text">Distracted by the readable content of a
                                                page when looking at its layout io The point of using Lorem Ipsum is
                                                that it has a more- or-less normal distribution of letters</p>
                                            <p className="services-details__text services-details__text-3">Distracted by the
                                                readable content of a
                                                page when loDistracted by the readable content of a page when looking at
                                                its layout io The point of using Lorem Ipsum is that it has a more-iso
                                                or-less normal distribution of letters, as opposed to using It is is a
                                                long established to th fact that anni reader will be distracted by the
                                                readable contentDistracted by the readable content of a page when
                                                looking at its layout io The point of using Lorem Ipsum is that it has a
                                                more-iso or-less normal distribution of letters, as opposed to using It
                                                is is a long established to th fact that anni reader will be distracted
                                                by the readable contento</p>
                                            <h3 className="services-details__title-2">Securing your peace </h3>
                                            <p className="services-details__text services-details__text-4">A specialized
                                                military unit tasked with gathering information and <br/>conducting
                                                surveillance in high-risk </p>
                                            <ul className="process-one__process-list list-unstyled">
                                                <li>
                                                    <div className="process-one__count"></div>
                                                    <div className="icon">
                                                        <span className="icon-peace-mind"></span>
                                                    </div>
                                                    <h3><Link href="about">Peace Mind</Link></h3>
                                                </li>
                                                <li>
                                                    <div className="process-one__count"></div>
                                                    <div className="icon">
                                                        <span className="icon-shoes"></span>
                                                    </div>
                                                    <h3><Link href="about">Threat Defense</Link></h3>
                                                </li>
                                                <li>
                                                    <div className="process-one__count"></div>
                                                    <div className="icon">
                                                        <span className="icon-emil-2"></span>
                                                    </div>
                                                    <h3><Link href="about">Digital Fortress</Link></h3>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="col-xl-4 col-lg-5">
                                        <div className="services-details__right">
                                            <div className="services-details__popular-services">
                                                <h3 className="services-details__popular-services-title">Popular Services
                                                </h3>
                                                <ul className="services-details__popular-services-list list-unstyled">
                                                    <li>
                                                        <div className="services-details__popular-services-img">
                                                            <img src="assets/images/services/services-lp-1-1.jpg"
                                                                alt=""/>
                                                        </div>
                                                        <div className="services-details__popular-services-content">
                                                            <p className="services-details__popular-services-date"><span
                                                                    className="icon-calender"></span>October 19, 2023</p>
                                                            <h3><Link href="#">Connect Innovate Succeed the design</Link></h3>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="services-details__popular-services-img">
                                                            <img src="assets/images/services/services-lp-1-2.jpg"
                                                                alt=""/>
                                                        </div>
                                                        <div className="services-details__popular-services-content">
                                                            <p className="services-details__popular-services-date"><span
                                                                    className="icon-calender"></span>October 19, 2023</p>
                                                            <h3><Link href="#">Elevate Your Business with IT the most</Link>
                                                            </h3>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div className="services-details__popular-services-img">
                                                            <img src="assets/images/services/services-lp-1-3.jpg"
                                                                alt=""/>
                                                        </div>
                                                        <div className="services-details__popular-services-content">
                                                            <p className="services-details__popular-services-date"><span
                                                                    className="icon-calender"></span>October 19, 2023</p>
                                                            <h3><Link href="#">Simplify IT for Enhanced Productivity</Link>
                                                            </h3>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div className="services-details__get-in-touch">
                                                <h3 className="services-details__popular-services-title">Get in Touch
                                                </h3>
                                                <ul className="services-details__get-in-touch-list list-unstyled">
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-call"></span>
                                                        </div>
                                                        <p><Link href="tel:+888123456765">(+888) 123 456 765</Link></p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-email"></span>
                                                        </div>
                                                        <p><Link href="mailto:infoname@mail.com">infoname@mail.com</Link></p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-clock"></span>
                                                        </div>
                                                        <p>Mon-Sun : 9AM-5PM</p>
                                                    </li>
                                                    <li>
                                                        <div className="icon">
                                                            <span className="icon-pin"></span>
                                                        </div>
                                                        <p>4140 Parker Rd. Allentown, New Mexico 31134</p>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/*tab*/}
                        </div>
                    </div>
                </div>
            </div>
        </section>
        {/*Services Details End*/}




        {/*CTA One Start */}
        <section className="cta-one">
            <div className="container">
                <div className="cta-one__inner">
                    <div className="cta-one__bg"  style={{ backgroundImage: 'url(assets/images/backgrounds/cta-one-bg.jpg)' }} >
                    </div>
                    <div className="row">
                        <div className="col-xl-6 col-lg-6"></div>
                        <div className="col-xl-6 col-lg-6">
                            <div className="cta-one__right">
                                <h3 className="cta-one__title">Get Free Estimate</h3>
                                <p className="cta-one__text">Lorem Ipsum is simply is dumiomy is text Lorem Ipsum </p>
                                <form className="cta-one__form mc-form" data-url="MC_FORM_URL">
                                    <div className="cta-one__form-input-box">
                                        <input type="email" placeholder="Your email..." name="email"/>
                                        <button type="submit" className="cta-one__btn thm-btn">Login<span
                                                className="icon-plus"></span></button>
                                    </div>
                                </form>
                                <div className="mc-form__response"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        {/*CTA One End */}
                </div>

            </Layout>
        </>
    )
}