
import Layout from "@/components/layout/Layout"
import Link from "next/link"
export default function Home() {

    return (
        <>
            <Layout headerStyle={3} footerStyle={1} breadcrumbTitle="Blog">
                {/*Blog Page Start*/}
                <section className="blog-page">
                    <div className="container">
                        <div className="row">
                            <div className="col-xl-8 col-lg-7">
                                <div className="blog-page__left">
                                    <div className="blog-page__left-content">
                                        <div className="blog-page__single">
                                            <div className="blog-page__img-box">
                                                <div className="blog-page__img">
                                                    <img src="assets/images/news/blog-page-1-1.jpg" alt=""/>
                                                </div>
                                                <ul className="blog-page__meta list-unstyled">
                                                    <li>
                                                        <Link href="blog-details"><span className="icon-calender"></span>31
                                                            December,2022</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="blog-details"><span className="icon-tag"></span>Web
                                                            design</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="blog-details"><span className="icon-comment"></span>Comments
                                                            (05)</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div className="blog-page__content">
                                                <h3 className="blog-page__title"><Link href="blog-details">Secure today worry-free
                                                        tomorrow</Link></h3>
                                                <p className="blog-page__text">Web designing in a powerful way of just not an only
                                                    professions, however, in a passion for our Company. We have to a tendency to
                                                    believe the idea that smart looking of any websitet in on visitors.Web
                                                    designing in a powerful way of just not an only profession</p>
                                                <div className="blog-page__btn-box">
                                                    <Link href="#" className="blog-page__btn thm-btn">Read More<span
                                                            className="icon-arrow-right"></span></Link>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="blog-page__single">
                                            <div className="blog-page__img-box">
                                                <div className="blog-page__img">
                                                    <img src="assets/images/news/blog-page-1-1.jpg" alt=""/>
                                                </div>
                                                <ul className="blog-page__meta list-unstyled">
                                                    <li>
                                                        <Link href="blog-details"><span className="icon-calender"></span>31
                                                            December,2022</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="blog-details"><span className="icon-tag"></span>Web
                                                            design</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="blog-details"><span className="icon-comment"></span>Comments
                                                            (05)</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div className="blog-page__content">
                                                <h3 className="blog-page__title"><Link href="blog-details">Provides robust defense
                                                        mechanisms to</Link></h3>
                                                <p className="blog-page__text">Web designing in a powerful way of just not an only
                                                    professions, however, in a passion for our Company. We have to a tendency to
                                                    believe the idea that smart looking of any websitet in on visitors.Web
                                                    designing in a powerful way of just not an only profession</p>
                                                <div className="blog-page__btn-box">
                                                    <Link href="#" className="blog-page__btn thm-btn">Read More<span
                                                            className="icon-arrow-right"></span></Link>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="blog-page__single">
                                            <div className="blog-page__img-box">
                                                <div className="blog-page__img">
                                                    <img src="assets/images/news/blog-page-1-3.jpg" alt=""/>
                                                </div>
                                                <ul className="blog-page__meta list-unstyled">
                                                    <li>
                                                        <Link href="blog-details"><span className="icon-calender"></span>31
                                                            December,2022</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="blog-details"><span className="icon-tag"></span>Web
                                                            design</Link>
                                                    </li>
                                                    <li>
                                                        <Link href="blog-details"><span className="icon-comment"></span>Comments
                                                            (05)</Link>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div className="blog-page__content">
                                                <h3 className="blog-page__title"><Link href="blog-details">A security solution
                                                        that brings peace of mind</Link></h3>
                                                <p className="blog-page__text">Web designing in a powerful way of just not an only
                                                    professions, however, in a passion for our Company. We have to a tendency to
                                                    believe the idea that smart looking of any websitet in on visitors.Web
                                                    designing in a powerful way of just not an only profession</p>
                                                <div className="blog-page__btn-box">
                                                    <Link href="#" className="blog-page__btn thm-btn">Read More<span
                                                            className="icon-arrow-right"></span></Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-xl-4 col-lg-5">
                                <div className="sidebar">
                                    <div className="sidebar__single sidebar__search">
                                        <div className="sidebar__title-box">
                                            <h3 className="sidebar__title">Search Here</h3>
                                        </div>
                                        <form action="#" className="sidebar__search-form">
                                            <input type="search" placeholder="Search.."/>
                                            <button type="submit"><i className="icon-search"></i></button>
                                        </form>
                                    </div>
                                    <div className="sidebar__single sidebar__category">
                                        <div className="sidebar__title-box">
                                            <h3 className="sidebar__title">Category</h3>
                                        </div>
                                        <ul className="sidebar__category-list list-unstyled">
                                            <li>
                                                <Link href="blog-details">Outdoor camera</Link>
                                            </li>
                                            <li>
                                                <Link href="blog-details">Indoor camera</Link>
                                            </li>
                                            <li>
                                                <Link href="blog-details">Wireless camera</Link>
                                            </li>
                                            <li>
                                                <Link href="blog-details">Night vision camera</Link>
                                            </li>
                                            <li>
                                                <Link href="blog-details">Motion detection setup</Link>
                                            </li>
                                            <li>
                                                <Link href="blog-details">CCTV system</Link>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="sidebar__single sidebar__post">
                                        <div className="sidebar__title-box">
                                            <h3 className="sidebar__title">Popular Post</h3>
                                        </div>
                                        <ul className="sidebar__post-list list-unstyled">
                                            <li>
                                                <div className="sidebar__post-image">
                                                    <img src="assets/images/news/lp-1.jpg" alt=""/>
                                                </div>
                                                <div className="sidebar__post-content">
                                                    <p className="sidebar__post-date"><span className="icon-calender"></span>October 19,
                                                        2022
                                                    </p>
                                                    <h3 className="sidebar__post-title"><Link href="blog-details">Your safety is
                                                            our <br/> priority</Link></h3>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="sidebar__post-image">
                                                    <img src="assets/images/news/lp-2.jpg" alt=""/>
                                                </div>
                                                <div className="sidebar__post-content">
                                                    <p className="sidebar__post-date"><span className="icon-calender"></span>25 August,
                                                        2023
                                                    </p>
                                                    <h3 className="sidebar__post-title"><Link href="blog-details">Protecting what
                                                            <br/>
                                                            matters most</Link></h3>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="sidebar__post-image">
                                                    <img src="assets/images/news/lp-3.jpg" alt=""/>
                                                </div>
                                                <div className="sidebar__post-content">
                                                    <p className="sidebar__post-date"><span className="icon-calender"></span>28 August,
                                                        2023
                                                    </p>
                                                    <h3 className="sidebar__post-title"><Link href="blog-details">Guarding your
                                                            peace <br/> of mind</Link></h3>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="sidebar__single sidebar__tag">
                                        <div className="sidebar__title-box">
                                            <h3 className="sidebar__title">Popular Tags</h3>
                                        </div>
                                        <div className="sidebar__tag-list">
                                            <Link href="blog-details">TechPros</Link>
                                            <Link href="blog-details">NetWorks</Link>
                                            <Link href="blog-details">CyberSafe</Link>
                                            <Link href="blog-details">Web</Link>
                                            <Link href="blog-details">InnovIT</Link>
                                            <Link href="blog-details">TechSavvy</Link>
                                            <Link href="blog-details">SoftwareMasters</Link>
                                        </div>
                                    </div>
                                    <div className="sidebar__single sidebar__newsletter">
                                        <div className="sidebar__title-box">
                                            <h3 className="sidebar__title">Newsletter</h3>
                                        </div>
                                        <p className="sidebar__newsletter-text">Subscribe for get more help and information</p>
                                        <form action="#" className="sidebar__newsletter-form">
                                            <input type="email" placeholder="E-mail Adress"/>
                                            <button type="submit"><i className="icon-paper-plan"></i></button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-xl-12">
                                <div className="blog-page__pagination-box">
                                    <div className="blog-page__pagination">
                                        <ul className="pg-pagination list-unstyled">
                                            <li className="prev">
                                                <Link href="blog-details" aria-label="Prev"><i
                                                        className="icon-arrow-right"></i></Link>
                                            </li>
                                            <li className="count"><Link href="blog-details">01</Link></li>
                                            <li className="count"><Link href="blog-details">02</Link></li>
                                            <li className="count"><Link href="blog-details">03</Link></li>
                                            <li className="next">
                                                <Link href="blog-details" aria-label="Next"><i
                                                        className="icon-arrow-right"></i></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                {/*Blog Page End*/}


                {/*CTA One Start */}
                <section className="cta-one">
                    <div className="container">
                        <div className="cta-one__inner">
                            <div className="cta-one__bg"  style={{ backgroundImage: 'url(assets/images/backgrounds/cta-one-bg.jpg)' }} >
                            </div>
                            <div className="row">
                                <div className="col-xl-6 col-lg-6"></div>
                                <div className="col-xl-6 col-lg-6">
                                    <div className="cta-one__right">
                                        <h3 className="cta-one__title">Get Free Estimate</h3>
                                        <p className="cta-one__text">Lorem Ipsum is simply is dumiomy is text Lorem Ipsum </p>
                                        <form className="cta-one__form mc-form" data-url="MC_FORM_URL">
                                            <div className="cta-one__form-input-box">
                                                <input type="email" placeholder="Your email..." name="email"/>
                                                <button type="submit" className="cta-one__btn thm-btn">Login<span
                                                        className="icon-plus"></span></button>
                                            </div>
                                        </form>
                                        <div className="mc-form__response"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                {/*CTA One End */}

            </Layout>
        </>
    )
}