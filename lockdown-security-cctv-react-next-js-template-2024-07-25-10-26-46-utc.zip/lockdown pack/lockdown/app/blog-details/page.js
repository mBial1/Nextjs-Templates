
import Layout from "@/components/layout/Layout"
import Link from "next/link"
export default function Home() {

    return (
        <>
            <Layout headerStyle={3} footerStyle={1} breadcrumbTitle="Blog Details">
                {/*Blog Details Start*/}
                <section className="blog-details">
                    <div className="container">
                        <div className="row">
                            <div className="col-xl-8 col-lg-7">
                                <div className="blog-details__left">
                                    <div className="blog-details__content">
                                        <div className="blog-details__img-box">
                                            <div className="blog-details__img">
                                                <img src="assets/images/news/blog-details-img-1.jpg" alt=""/>
                                            </div>
                                            <div className="blog-details__meta">
                                                <Link href="#"><span className="icon-calender"></span>31 December,2022</Link>
                                                <Link href="#"><span className="icon-tag"></span>Web design</Link>
                                                <Link href="#"><span className="icon-comment"></span>Comments (05)</Link>
                                            </div>
                                        </div>
                                        <div className="blog-details__content-2">
                                            <h3 className="blog-details__title-1">Secure today worry-free tomorrow</h3>
                                            <p className="blog-details__text-1">Web designing in a powerful way of just not an only
                                                professions, however, in a passion for our Company. We have to a tendency to
                                                believe
                                                the idea that smart looking of any websitet in on visitors.Web designing in a
                                                powerful way of just not an only profession</p>
                                            <p className="blog-details__text-2">Web designing in a powerful way of just not an only
                                                professions, however, in a passion for our Company. We have to a tendency to
                                                believe
                                                the idea that smart looking of any websitet in on visitors.Web designing in a
                                                powerful way of just not an only profession</p>
                                            <div className="blog-details__img-and-text-box">
                                                <div className="blog-details__text-img">
                                                    <img src="assets/images/news/blog-details-text-box-img.jpg" alt=""/>
                                                </div>
                                                <div className="blog-details__text-box">
                                                    <p className="blog-details__text-3">Contrary to popular belief, Lorem Ipsum is
                                                        not simply the a random text. It has roots in a piece of classNameical Latin
                                                        and literature from 45 BC, making it over 2000 years old. Richard
                                                        McClintock, a Latin professor at Hampden-Sydney College in Virginia,
                                                        looked up one of the more obscure Latin words, consectetur, from a Lorem
                                                        Contrary to popular belief, Lorem Ipsum is not simply the a random text.
                                                        It has roots in a piece of classNameical</p>
                                                    <div className="blog-details__tag-box">
                                                        <Link href="#">Medicine</Link>
                                                        <Link href="#">Doctors</Link>
                                                        <Link href="#">Babyhealthcare</Link>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="blog-details__review">
                                        <h3 className="blog-details__review-title">Reviews:</h3>
                                        <div className="blog-details__review-single">
                                            <p>It is a long established fact that a reader will be distracted by the readable
                                                content of a page when looking at its layout. The point of using Lorem Ipsum is
                                                that it has a more-or-less normal distribution of letters</p>
                                            <span>Mark wood</span>
                                        </div>
                                        <div className="blog-details__review-single">
                                            <p>It is a long established fact that a reader will be distracted by the readable
                                                content of a page when looking at its layout. The point of using Lorem Ipsum is
                                                that it has a more-or-less normal distribution of letters</p>
                                            <span>robert hardson</span>
                                        </div>
                                    </div>
                                    <div className="comment-form-box">
                                        <h3 className="blog-details__review-title">Leave a Reply</h3>
                                        <div className="comment-form">
                                            <p>Your E-mail address will be not published.Required fields are marked*</p>
                                            <form action="assets/inc/sendemail.php"
                                                className="comment-one__form contact-form-validated">
                                                <div className="row">
                                                    <div className="col-xl-6 col-lg-6">
                                                        <div className="comment-form__input-box">
                                                            <input type="text" placeholder="Name*" name="name"/>
                                                        </div>
                                                    </div>
                                                    <div className="col-xl-6 col-lg-6">
                                                        <div className="comment-form__input-box">
                                                            <input type="email" placeholder="E-mail" name="email"/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-xl-12 col-lg-12">
                                                        <div className="comment-form__input-box text-message-box">
                                                            <textarea name="message" placeholder="Comment"></textarea>
                                                        </div>
                                                        <div className="checked-box">
                                                            <input type="checkbox" name="skipper1" id="skipper"/>
                                                            <label ><span></span>Save my name,email and website in
                                                                this browser for the next time</label>
                                                        </div>
                                                        <div className="comment-form__btn-box">
                                                            <button type="submit" className="thm-btn comment-form__btn">Submit
                                                                comment</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                            <div className="result"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-xl-4 col-lg-5">
                                <div className="sidebar">
                                    <div className="sidebar__single sidebar__search">
                                        <div className="sidebar__title-box">
                                            <h3 className="sidebar__title">Search Here</h3>
                                        </div>
                                        <form action="#" className="sidebar__search-form">
                                            <input type="search" placeholder="Search.."/>
                                            <button type="submit"><i className="icon-search"></i></button>
                                        </form>
                                    </div>
                                    <div className="sidebar__single sidebar__category">
                                        <div className="sidebar__title-box">
                                            <h3 className="sidebar__title">Category</h3>
                                        </div>
                                        <ul className="sidebar__category-list list-unstyled">
                                            <li>
                                                <Link href="blog-details">Outdoor camera</Link>
                                            </li>
                                            <li>
                                                <Link href="blog-details">Indoor camera</Link>
                                            </li>
                                            <li>
                                                <Link href="blog-details">Wireless camera</Link>
                                            </li>
                                            <li>
                                                <Link href="blog-details">Night vision camera</Link>
                                            </li>
                                            <li>
                                                <Link href="blog-details">Motion detection setup</Link>
                                            </li>
                                            <li>
                                                <Link href="blog-details">CCTV system</Link>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="sidebar__single sidebar__post">
                                        <div className="sidebar__title-box">
                                            <h3 className="sidebar__title">Popular Post</h3>
                                        </div>
                                        <ul className="sidebar__post-list list-unstyled">
                                            <li>
                                                <div className="sidebar__post-image">
                                                    <img src="assets/images/news/lp-1.jpg" alt=""/>
                                                </div>
                                                <div className="sidebar__post-content">
                                                    <p className="sidebar__post-date"><span className="icon-calender"></span>October 19,
                                                        2022
                                                    </p>
                                                    <h3 className="sidebar__post-title"><Link href="blog-details">Your safety is
                                                            our <br/> priority</Link></h3>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="sidebar__post-image">
                                                    <img src="assets/images/news/lp-2.jpg" alt=""/>
                                                </div>
                                                <div className="sidebar__post-content">
                                                    <p className="sidebar__post-date"><span className="icon-calender"></span>25 August,
                                                        2023
                                                    </p>
                                                    <h3 className="sidebar__post-title"><Link href="blog-details">Protecting what
                                                            <br/>
                                                            matters most</Link></h3>
                                                </div>
                                            </li>
                                            <li>
                                                <div className="sidebar__post-image">
                                                    <img src="assets/images/news/lp-3.jpg" alt=""/>
                                                </div>
                                                <div className="sidebar__post-content">
                                                    <p className="sidebar__post-date"><span className="icon-calender"></span>28 August,
                                                        2023
                                                    </p>
                                                    <h3 className="sidebar__post-title"><Link href="blog-details">Guarding your
                                                            peace <br/> of mind</Link></h3>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="sidebar__single sidebar__tag">
                                        <div className="sidebar__title-box">
                                            <h3 className="sidebar__title">Popular Tags</h3>
                                        </div>
                                        <div className="sidebar__tag-list">
                                            <Link href="blog-details">TechPros</Link>
                                            <Link href="blog-details">NetWorks</Link>
                                            <Link href="blog-details">CyberSafe</Link>
                                            <Link href="blog-details">Web</Link>
                                            <Link href="blog-details">InnovIT</Link>
                                            <Link href="blog-details">TechSavvy</Link>
                                            <Link href="blog-details">SoftwareMasters</Link>
                                        </div>
                                    </div>
                                    <div className="sidebar__single sidebar__newsletter">
                                        <div className="sidebar__title-box">
                                            <h3 className="sidebar__title">Newsletter</h3>
                                        </div>
                                        <p className="sidebar__newsletter-text">Subscribe for get more help and information</p>
                                        <form action="#" className="sidebar__newsletter-form">
                                            <input type="email" placeholder="E-mail Adress"/>
                                            <button type="submit"><i className="icon-paper-plan"></i></button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                {/*Blog Details End*/}

                {/*CTA One Start */}
                <section className="cta-one">
                    <div className="container">
                        <div className="cta-one__inner">
                            <div className="cta-one__bg"  style={{ backgroundImage: 'url(assets/images/backgrounds/cta-one-bg.jpg)' }} >
                            </div>
                            <div className="row">
                                <div className="col-xl-6 col-lg-6"></div>
                                <div className="col-xl-6 col-lg-6">
                                    <div className="cta-one__right">
                                        <h3 className="cta-one__title">Get Free Estimate</h3>
                                        <p className="cta-one__text">Lorem Ipsum is simply is dumiomy is text Lorem Ipsum </p>
                                        <form className="cta-one__form mc-form" data-url="MC_FORM_URL">
                                            <div className="cta-one__form-input-box">
                                                <input type="email" placeholder="Your email..." name="email"/>
                                                <button type="submit" className="cta-one__btn thm-btn">Login<span
                                                        className="icon-plus"></span></button>
                                            </div>
                                        </form>
                                        <div className="mc-form__response"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                {/*CTA One End */}

            </Layout>
        </>
    )
}