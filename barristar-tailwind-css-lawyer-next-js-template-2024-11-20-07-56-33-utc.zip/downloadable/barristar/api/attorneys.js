import atimg1 from '/public/images/expert/1.jpg'
import atimg2 from '/public/images/expert/2.jpg'
import atimg3 from '/public/images/expert/3.jpg'
import atimg4 from '/public/images/expert/4.jpg'
import atimg5 from '/public/images/expert/5.jpg'
import atimg6 from '/public/images/expert/6.jpg'


const Attorneys = [
   {
      Id: '1',
      AtImg: atimg1,
      name: 'Alecgander Harry',
      slug: 'Alecgander-Harry',
      title: 'Family Lawyer',
   },
   {
      Id: '2',
      AtImg: atimg2,
      name: 'Lily Watson',
      slug: 'Lily-Watson',
      title: 'Divorce Lawer',
   },
   {
      Id: '3',
      AtImg: atimg3,
      name: 'Willam Stephen',
      slug: 'Willam-Stephen',
      title: 'Criminal Lawer',
   },
   {
      Id: '4',
      AtImg: atimg4,
      name: 'Eshan Golly',
      slug: 'Eshan-Golly',
      title: 'Family Lawyer',
   },
   {
      Id: '5',
      AtImg: atimg5,
      name: 'Daniel Dambeldor',
      slug: 'Daniel-Dambeldor',
      title: 'Divorce Lawer',
   },
   {
      Id: '6',
      AtImg: atimg6,
      name: 'Darcy Alec',
      slug: 'Darcy-Alec',
      title: 'Criminal Lawer',
   }

]

export default Attorneys;