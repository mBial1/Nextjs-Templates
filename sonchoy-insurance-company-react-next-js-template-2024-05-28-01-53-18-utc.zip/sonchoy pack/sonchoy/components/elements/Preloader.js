export default function Preloader() {
    return (
        <>
            <div className="preloader">
                <div className="preloader__image"></div>
            </div>


        </>
    )
}
