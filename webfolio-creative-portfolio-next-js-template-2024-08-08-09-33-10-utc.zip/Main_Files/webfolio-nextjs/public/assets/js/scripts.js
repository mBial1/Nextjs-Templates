if (typeof window !== 'undefined')
  new WOW({
    animateClass: 'animated',
    offset: 100,
  }).init();
