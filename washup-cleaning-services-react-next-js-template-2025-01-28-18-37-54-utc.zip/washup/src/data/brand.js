// Brand One
export const BrandOneData = [
    {
        id: 1,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
    },
    {
        id: 2,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
    },
    {
        id: 3,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
    },
    {
        id: 4,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
    },
    {
        id: 5,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
    },
    {
        id: 6,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
    },
    {
        id: 7,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
    },
    {
        id: 8,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
    },
];

// Brand Three
export const BrandThreeData = [
    {
        id: 1,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
        delay: "0.1s",
    },
    {
        id: 2,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
        delay: "0.3s",
    },
    {
        id: 3,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
        delay: "0.5s",
    },
    {
        id: 4,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
        delay: "0.7s",
    },
    {
        id: 5,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
        delay: "0.1s",
    },
    {
        id: 6,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
        delay: "0.3s",
    },
    {
        id: 7,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
        delay: "0.5s",
    },
    {
        id: 8,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
        delay: "0.7s",
    },
    {
        id: 9,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
        delay: "0.1s",
    },
    {
        id: 10,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
        delay: "0.3s",
    },
    {
        id: 11,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
        delay: "0.5s",
    },
    {
        id: 12,
        image: "/assets/images/brand/brand-1-1.png",
        alt: "Brand",
        link: "#",
        delay: "0.7s",
    },
];